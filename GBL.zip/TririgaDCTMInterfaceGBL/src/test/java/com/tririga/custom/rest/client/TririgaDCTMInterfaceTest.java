//
//package com.tririga.custom.rest.client;
//
//
//import org.apache.log4j.Logger;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//
//import com.tririga.documentum.rest.client.DCTMRestErrorException;
//import com.tririga.documentum.rest.client.TririgaDCTMInterface;
//import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
//import com.tririga.documentum.rest.client.model.json.JsonRestError;
//import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
//import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;
//
///**
// * JUnit test class for TririgaDCTMInterface.
// */
//public class TririgaDCTMInterfaceTest
//{
//
//	TririgaDCTMInterface dctmInterface;
//	TririgaDCTMMappingResponse response;
//	TririgaDCTMMappingRequest request;
////	private static String trustStore = "javax.net.ssl.trustStore";
////	private static String trustStorePassword = "javax.net.ssl.trustStorePassword";
////	private static String trustStoreFormat = "javax.net.ssl.trustStoreType";
////	private static String trustStorePath = "";
////	//./src/main/resources/com/tririga/documentum/rest/client/util/cacerts
////	private static String trustStorePasswordValue = "changeit";
////	private static String trustStoreFormatValue = "jks";
//	private static Logger logger = Logger.getLogger(TririgaDCTMInterfaceTest.class);
//	
//
//	/**
//	 * This method is called before the execution of each test case and is used
//	 * to instantiate the variables.
//	 * 
//	 * @throws java.lang.Exception
//	 */
////	static
////	{
////		URL resource = TririgaDCTMHelper.class.getResource("cacerts");
////			try {
////				trustStorePath = Paths.get(resource.toURI()).toFile().toString();
////			} catch (URISyntaxException e) {
////				e.printStackTrace();
////			}
////		//File resourcesDirectory = new File("src/test/java/ClassLoader.java");
////		//trustStorePath = resourcesDirectory.getAbsolutePath();
////		//Path resourceDirectory = Paths.get("cacerts");
////		
////		logger.info("Path " + trustStorePath);
////		System.setProperty(trustStore, trustStorePath);
////		System.setProperty(trustStorePassword, trustStorePasswordValue);
////		System.setProperty(trustStoreFormat, trustStoreFormatValue);
////	}
//
//	@Before
//	public void setUp() throws Exception
//	{
//		dctmInterface = new TririgaDCTMInterface();
//		request = new TririgaDCTMMappingRequest();
//		response = new TririgaDCTMMappingResponse();
//	//	request.setUrl("https://dev-dctmtri.wal-mart.com/us-pm/docrest/");		//https://dev-dctmtri.wal-mart.com/jp/docrest
//	//	request.setRepos("dmtririga_us_pm");		//dmtririga_ja
//	//	request.setUserId("svcdctmuststrest"); //svcdctmjptstrest
//	//	request.setPassword("gfSzd9jC7nJg9jC6e0jqnw=="); //tywVG9C8W+58YgYbgnT5nw==
//		request.setUrl("https://dev-dctmtri.wal-mart.com/jp/docrest");		//https://dev-dctmtri.wal-mart.com/jp/docrest
//		request.setRepos("dmtririga_ja");		//dmtririga_ja
//		request.setUserId("svcdctmjptstrest"); //svcdctmjptstrest
//		request.setPassword("tywVG9C8W+58YgYbgnT5nw=="); 
//		request.setExtension("false");
//		
////		UserID: svcdctmprodsso
////		Password:kRSrmNfBFqy9BgT
////
////		User id : svcdctmprodmigart
////		Pwd : kRy9BgTSrmNfBFq
//	}
//	
//	/**
//	 * FirstName : JPDCTM ; LastName : RestSvc
//	 *  Integration : svcdctmjptstrest
//		SSO : svcdctmjptstsso
//		Artifact/Migration : svcdctmjptstmigart
//	 */
//	
//	// Please set "NonExpiring" password for mentioned service account.As part of Japan Tririga-Documentum Project, we need services account for Integration/Migration/Artifact Installation between Tririga -Documentum Applications
//
//	/**
//	 * This method is called after the execution of each test case and is used
//	 * to nullify the variables.
//	 * 
//	 * @throws java.lang.Exception
//	 */
//	@After
//	public void tearDown() throws Exception
//	{
//		dctmInterface = null;
//		request = null;
//		response = null;
//	}
//
//	/**
//	 * @throws Exception
//	 *             -- Boolean 4. I’m creating a Building form in Portfolio for
//	 *             US market
//	 */
//	@Test
//	public void testCreateFoldersWithBoolean()
//	{
//				
//		// Destination Params
//		//request.setCabinetName("US Property Management (PM)"); //JP Facility Management (FM)
//		request.setCabinetName("JP Facility Management (FM)");
//		request.setFolderNametoCreate("Test 123");			
//		request.setFolderNameInCabinet("Test 5");
//		request.setCustomFolderType("wm_jp_fm_folder");//wm_us_pm_folder
//
//		// Template Folder Params
//		request.setTemplateCabinetName("TririgaTemplates");
//		request.setTemplateFolderName("US CM");
//		request.setFormName("triCapitalProject");
//
//		// Generic
//		request.setCopyCreateFolder(false);
//		request.setAction("1");
//
//		try
//		{
//			response = dctmInterface.invokeDCTM(request);
//			logger.info("Obj Id: "+response.getObjectId());
//			
//		}
//		catch(TririgaDCTMIntegrationException e)
//		{
//			logger.info("E Msg1 " + e.getLocalizedMessage());			
//		
//		}
//		
//		catch(Exception e)
//		{
//			logger.info("In Exception");
//			e.printStackTrace();
//			logger.info("E1 Msg1 " + e.getLocalizedMessage());
//			logger.info("E1 Msg2 " + e.getMessage());
//			logger.info("E1 Msg4 " + e.getCause());
//		}
//
//	}
//	
///*	@Test
//	public void testSpace() throws UnsupportedEncodingException 
//	{
////		byte[] inputData = "San thosh asdasd";
////		String stringBefore = new String(inputData, Charset.forName("UTF-8"));
////		String withoutSpaces = stringBefore.replaceAll("\\s+", "");
////		byte[] outputData = withoutSpaces.getBytes(Charset.forName("UTF-8"));
//		
//		String input = " Documentos de origen (Home Documents)/  Políticas y Procedimientos (Policies)/Políticas/";
//		String response=null;
//		//new String(input.getBytes("ISO-8859-1"),"UTF-8");
//		response= new String(input.getBytes("UTF-8"),"UTF-8");
//		//new String(input.getBytes(Charset.forName("UTF-8")), Charset.forName("Windows-1252"));
//		System.out.println("response is \""+response+"\"");
//		String output = response.replaceAll("\\t+","");
//		//StringUtils.trim(str)
//		//String stripppedString = input.replaceAll("(^ )|( $)", "");
//		String stripppedString =input.replace("/ /g", "");
//		//System.out.println("stripppedString is \""+stripppedString+"\"");
//		System.out.println("output is \""+output+"\"");
//	}*/
//
//	/**
//	 * @throws Exception
//	 */
////	@Test
////	public void testCreate()
////	{
////		request.setCabinetName("San");
////		request.setFolderNametoCreate("San14");
////		request.setFolderNameInCabinet("");
////		request.setAction("2");
////		try
////		{
////
////			response = dctmInterface.invokeDCTM(request);
////		}
////		catch(DCTMRestErrorException e)
////		{
////			e.printStackTrace();
////		}
////		catch(Exception e)
////		{
////			e.printStackTrace();
////		}
////
////	}
//
//	/**
//	 * @throws Exception
//	 */
////	@Test
////	public void testLookUp()
////	{
////		request.setObjectId("0b015f928000c558");
////		request.setAction("3");
////		request.setNewFolderName("127779826,1,NEW,Clinic,127779826,Testing");
////		try
////		{
////			response = dctmInterface.invokeDCTM(request);
////			System.out.println("response " + response.getUpdatedObjId());
////		}
////		catch(DCTMRestErrorException e)
////		{
////			System.out.println("In Catch Block");
////			e.printStackTrace();
////		}
////		catch(Exception e)
////		{
////			System.out.println("In Exception Catch Block");
////			e.printStackTrace();
////		}
////
////	}
//
//	/**
//	 * @throws Exception
//	 */
////	@Test
////	public void testCopyCreate()
////	{
////		// Destination Params
////		request.setCabinetName("Construction Management (CM)");
////		request.setFolderNametoCreate("SanACL1");
////		request.setFolderNameInCabinet("Capital Project");
////
////		// Template Folder Params
////		request.setTemplateCabinetName("Templates");
////		request.setTemplateFolderName("CM");
////		request.setFormName("triCapitalProject");
////
////		// Generic
////		request.setCopyCreateFolder(false);
////		request.setAction("4");
////
////		try
////		{
////			response = dctmInterface.invokeDCTM(request);
////		}
////		catch(DCTMRestErrorException e)
////		{
////			System.out.println("In Catch Block");
////			e.printStackTrace();
////		}
////		catch(Exception e1)
////		{
////			e1.printStackTrace();
////		}
////
////	}
//
//	/**
//	 * @throws Exception
//	 */
////	@Test
////	public void testCopyRename()
////	{
////		// request.setCabinetName("SanTemp");
////		// request.setFolderNametoCreate("San_AR_US2");
////		// request.setAction("5");
////		// request.setFormName("US");
////		// request.setTemplateFolderName("CM");
////
////		// Destination Params
////		request.setCabinetName("Construction Management (CM)");
////		request.setFolderNametoCreate("boolean1");
////		// request.setFolderNameInCabinet("Capital Project");
////
////		// Template Folder Params
////		request.setFormName("triCapitalProject");
////		request.setTemplateFolderName("CM");
////
////		request.setCopyCreateFolder(true);
////		request.setAction("6");
////		try
////		{
////			response = dctmInterface.invokeDCTM(request);
////		}
////		catch(DCTMRestErrorException e)
////		{
////			System.out.println("In Catch Block");
////			e.printStackTrace();
////		}
////		catch(Exception e1)
////		{
////			e1.printStackTrace();
////		}
////
////	}
//
//	/**
//	 * @throws Exception
//	 */
////	@Test
////	public void testArchive()
////	{
////		request.setCabinetName("SanTemp");
////		request.setFolderNametoMove("San12");
////		request.setAction("4");
////		request.setFolderNameInCabinet("");
////		request.setFolderNameAtArchive("building");
////		try
////		{
////			response = dctmInterface.invokeDCTM(request);
////		}
////		catch(DCTMRestErrorException e)
////		{
////			System.out.println("In Catch Block");
////			e.printStackTrace();
////		}
////		catch(Exception e)
////		{
////			System.out.println("In Catch Block");
////			e.printStackTrace();
////		}
////
////	}
//	
////	@Test
//	public void testDelete()
//	{
//		// Destination Params
//		request.setObjectId("0b015f9480004210");
//		request.setAction("6");
//
//		try
//		{
//			response = dctmInterface.invokeDCTM(request);
//		} //RestClientException
////		catch(JsonRestError e)
////		{
////			logger.info("In JsonRestError");
////			logger.info("E Msg1 " + e.getLocalizedMessage());
////			logger.info("E Msg2 " + e.getMessage());
////			logger.info("E Msg3 " + e.getError());
////			logger.info("E Msg4 " + e.getCause());
////		}
//		catch(DCTMRestErrorException e)
//		{
//			logger.info("In DCTMRestErrorException");
//			//e.printStackTrace();
//			logger.info("E Msg1 " + e.getLocalizedMessage());
//			logger.info("E Msg2 " + e.getMessage());
//			logger.info("E Msg3 " + e.getError());
//			logger.info("E Msg4 " + e.getCause());
//		}
//		catch(ExceptionInInitializerError e)
//		{
//			logger.info("In ExceptionInInitializerError");
//			//e.printStackTrace();
//			logger.info("E Msg1 " + e.getLocalizedMessage());
//			logger.info("E Msg2 " + e.getMessage());
//			logger.info("E Msg4 " + e.getCause());
//		}
//		catch(Exception e)
//		{
//			logger.info("In Exception");
//			//e.printStackTrace();
//			logger.info("E1 Msg1 " + e.getLocalizedMessage());
//			logger.info("E1 Msg2 " + e.getMessage());
//			logger.info("E1 Msg4 " + e.getCause());
//		}
//
//	}
//
//}
