//
//package com.tririga.custom.rest.client;
//
//import java.security.Key;
//import java.util.Base64;
//
//import javax.crypto.Cipher;
//import javax.crypto.spec.SecretKeySpec;
//
//import org.junit.Test;
//
//public class DCTMEncryptDecryptTest
//{
//
//	private static Cipher cipher;
//
//	
//	@Test
//	public void testEncDec() throws Exception
//	{
//		String strToEncrypt = "Jaffa123"; // string to encrypt
//		System.out.println("String Before Encryption: " + strToEncrypt);
//
//		String encryptedText = encrypt(strToEncrypt);
//		System.out.println("Encrypted Text After Encryption: " + encryptedText);
//
//		String decryptedText = decrypt("tywVG9C8W+58YgYbgnT5nw==");
//		System.out.println("Decrypted Text After Decryption: " + decryptedText);
//	}
//
//	public static String encrypt(String strToEncrypt) throws Exception
//	{
//		cipher = Cipher.getInstance("AES");
//		
//		String key = "f#6kn$46uv*q9%t7"; // junk key
//		Key aesKey  = new SecretKeySpec(key.getBytes(), "AES");
//		
//		byte[] strToEncryptByte = strToEncrypt.getBytes();
//		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
//		byte[] encryptedByte = cipher.doFinal(strToEncryptByte);
//		Base64.Encoder encoder = Base64.getEncoder();
//		String encryptedText = encoder.encodeToString(encryptedByte);
//		return encryptedText;
//	}
//
//	public static String decrypt(String encryptedText) throws Exception
//	{
//		cipher = Cipher.getInstance("AES");
//		
//		String key = "f#6kn$46uv*q9%t7"; // junk key
//		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
//		
//		Base64.Decoder decoder = Base64.getDecoder();
//		byte[] encryptedTextByte = decoder.decode(encryptedText);
//		cipher.init(Cipher.DECRYPT_MODE, aesKey);
//		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
//		String decryptedText = new String(decryptedByte);
//		return decryptedText;
//	}
//}
