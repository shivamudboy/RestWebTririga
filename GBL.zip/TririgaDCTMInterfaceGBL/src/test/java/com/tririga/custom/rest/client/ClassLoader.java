///**
// * 
// */
//package com.tririga.custom.rest.client;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.Properties;
//import java.util.Set;
//
//import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;
//
//
///**
// * @author saarv1
// *
// */
//public class ClassLoader {
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//
//		//propLoad();
//		triLoader();
//	}
//
//	public static String triLoader() {
//		Properties prop = new Properties();
//		InputStream input;
//		String strCabinet = "JP Facility Management (FM)";
//		String customFolderType = null;
//		try {
//
//			input = TririgaDCTMHelper.class
//					.getResourceAsStream("customFolderType.properties");
//			prop.load(input);
//			System.out.println("Property File Loaded Succesfully");
//			Set<String> propertyNames = prop.stringPropertyNames();
//			for (String Property : propertyNames) {
//				//System.out.println(Property + ":" + prop.getProperty(Property));
//				String propKey = Property.replace("_", " ");
//				if (propKey.contains(strCabinet)) {
//					customFolderType = prop.getProperty(strCabinet.replace(" ",
//							"_"));
//					System.out.println("JP " + customFolderType);
//					System.out.println("San JP 仕事の仕事\\Work Task");
//				}
//				
//			}
//
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		return customFolderType;
//	}
//
//	private static void propLoad() {
//		Properties properties = new Properties();
//		String customFolderType = "";
//		String strCabinet = "JP Facility Management (FM)";
//
//		// Applying CustomFolder Type
//		try {
//			properties.load(TririgaDCTMHelper.class
//					.getResourceAsStream("customFolderType.properties"));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		String propKey = properties.keySet().toString().replace("_", " ");
//		if (propKey.contains(strCabinet)) {
//			customFolderType = properties.getProperty(strCabinet.replace(" ",
//					"_"));
//			System.out.println("JP " + customFolderType);
//		}
//	}
//
//
//}
