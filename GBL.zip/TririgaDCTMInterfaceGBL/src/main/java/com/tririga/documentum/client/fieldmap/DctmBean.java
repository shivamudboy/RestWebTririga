package com.tririga.documentum.client.fieldmap;

public class DctmBean {

	public String user;
	public String pass;
	public String url;
	public String docbase;
	public String extension;
	public String webUrl;
	public String cabinet;
	public String marketType;
	public String acl;

	public String cstDCTMCabinetNameTX;
	public String cstDCTMFolderNameTX;
	public String cstDCTMFolderTypeTX;
	public String cstDCTMCabFolderNameTX;
	public String cstDCTMCustFolderNameTX;
	public String cstStoreNumberTX;

	public String getCstStoreNumberTX() {
		return cstStoreNumberTX;
	}

	public void setCstStoreNumberTX(String cstStoreNumberTX) {
		this.cstStoreNumberTX = cstStoreNumberTX;
	}

	public String getCstDCTMCustFolderNameTX() {
		return cstDCTMCustFolderNameTX;
	}

	public void setCstDCTMCustFolderNameTX(String cstDCTMCustFolderNameTX) {
		this.cstDCTMCustFolderNameTX = cstDCTMCustFolderNameTX;
	}

	public String getCstDCTMCabFolderNameTX() {
		return cstDCTMCabFolderNameTX;
	}

	public void setCstDCTMCabFolderNameTX(String cstDCTMCabFolderNameTX) {
		this.cstDCTMCabFolderNameTX = cstDCTMCabFolderNameTX;
	}

	public String getCstDCTMCabinetNameTX() {
		return cstDCTMCabinetNameTX;
	}

	public void setCstDCTMCabinetNameTX(String cstDCTMCabinetNameTX) {
		this.cstDCTMCabinetNameTX = cstDCTMCabinetNameTX;
	}

	public String getCstDCTMFolderNameTX() {
		return cstDCTMFolderNameTX;
	}

	public void setCstDCTMFolderNameTX(String cstDCTMFolderNameTX) {
		this.cstDCTMFolderNameTX = cstDCTMFolderNameTX;
	}

	public String getCstDCTMFolderTypeTX() {
		return cstDCTMFolderTypeTX;
	}

	public void setCstDCTMFolderTypeTX(String cstDCTMFolderTypeTX) {
		this.cstDCTMFolderTypeTX = cstDCTMFolderTypeTX;
	}

	public String getCabinet() {
		return cabinet;
	}

	public void setCabinet(String cabinet) {
		this.cabinet = cabinet;
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getWebUrl() {
		return webUrl;
	}

	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public String getMarketType() {
		return marketType;
	}

	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDocbase() {
		return docbase;
	}

	public void setDocbase(String docbase) {
		this.docbase = docbase;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

}
