package com.tririga.documentum.rest.client.exception;

public class TririgaDCTMIntegrationException extends Exception{

	public TririgaDCTMIntegrationException (String message){
		super(message);
	}
	
}
