/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */

package com.tririga.documentum.rest.client;

import javax.annotation.concurrent.NotThreadSafe;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.model.Feed;
import com.tririga.documentum.rest.client.model.FolderLink;
import com.tririga.documentum.rest.client.model.HomeDocument;
import com.tririga.documentum.rest.client.model.LinkRelation;
import com.tririga.documentum.rest.client.model.Linkable;
import com.tririga.documentum.rest.client.model.ObjectAspects;
import com.tririga.documentum.rest.client.model.Repository;
import com.tririga.documentum.rest.client.model.RestObject;
import com.tririga.documentum.rest.client.model.RestType;
import com.tririga.documentum.rest.client.model.SearchFeed;
import com.tririga.documentum.rest.client.model.ValueAssistant;
import com.tririga.documentum.rest.client.model.ValueAssistantRequest;

/**
 * The sample REST client library
 */
@NotThreadSafe
public interface DCTMRestClient
{

	/**
	 * @return the http headers of the previous operation
	 */
	public HttpHeaders getHeaders();

	/**
	 * @return the http status of the previous operation
	 */
	public HttpStatus getStatus();

	/**
	 * enable streaming for the binary content transfer. especially useful when
	 * upload big files. only valid for the next operations. will be
	 * automatically disabled after the operation.
	 */
	public void enableStreamingForNextRequest();

	/**
	 * @return the cached HomeDocument object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public HomeDocument getHomeDocument() throws TririgaDCTMIntegrationException;

	/**
	 * @return the product info
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getProductInfo() throws TririgaDCTMIntegrationException;

	/**
	 * @return the cached Repositories feed
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<Repository> getRepositories() throws TririgaDCTMIntegrationException;

	/**
	 * @return the cached Repository object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Repository getRepository() throws TririgaDCTMIntegrationException;

	/**
	 * execute a readonly dql
	 * 
	 * @param dql
	 *            the dql to be executed
	 * @param params
	 *            the query parameters
	 * @return the query feed response
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> dql(String dql, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * execute the simple search
	 * 
	 * @param search
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public SearchFeed<RestObject> search(String search, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param params
	 * @return the cabinets feed based on query parameters
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getCabinets(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param cabinet
	 *            the cabinet name
	 * @param params
	 * @return the cabinet by its name
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getCabinet(String cabinet, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param parent
	 *            the parent object, e.g. cabinet, folder
	 * @param params
	 * @return the folders feed under the specified object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getFolders(RestObject parent, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param parent
	 *            the parent object, e.g. cabinet, folder
	 * @param params
	 * @return the documents (dm_document or its subtype) feed under the
	 *         specified object
	 * @throws TririgaDCTMIntegrationException       
	 */
	public Feed<RestObject> getDocuments(RestObject parent, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param parent
	 *            the parent object, e.g. cabinet, folder
	 * @param params
	 * @return the sysobjects (dm_sysobject or its subtype) feed under the
	 *         specified object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getObjects(RestObject parent, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param object
	 * @param params
	 * @return get the object by its self link
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject get(RestObject object, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param uri
	 * @param clazz
	 * @param params
	 * @return the single object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public <T> T get(String uri, Class<T> clazz, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a folder under specified folder/cabinet
	 * 
	 * @param parent
	 *            the folder/cabinet where the new folder will be created under
	 * @param newFolder
	 *            the new folder with its properties
	 * @param params
	 * @return the created folder
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createFolder(RestObject parent, RestObject newFolder, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param folderUri
	 * @param params
	 * @return the folder of the specified uri
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getFolder(String folderUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a sysobject (or its subtype) under specified parent's link rel
	 * 
	 * @param parent
	 *            the parent object where the new sysobject will be created
	 *            under
	 * @param rel
	 *            the LinkRelation used to create new object under the parent
	 * @param objectToCreate
	 *            the new object with its properties
	 * @param content
	 *            the binary content, it can be byte array, String,
	 *            javax.xml.transform.Source,
	 *            org.springframework.core.io.Resource, JAXB object, and Jackson
	 *            json object
	 * @param params
	 * @return the created sysobject
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createObject(RestObject parent, LinkRelation rel, RestObject objectToCreate, Object content,
			String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a sysobject (or its subtype) under specified folder/cabinet
	 * 
	 * @param parent
	 *            the folder/cabinet where the new sysobject will be created
	 *            under
	 * @param objectToCreate
	 *            the new object with its properties
	 * @param content
	 *            the binary content, it can be byte array, String,
	 *            javax.xml.transform.Source,
	 *            org.springframework.core.io.Resource, JAXB object, and Jackson
	 *            json object
	 * @param params
	 * @return the created sysobject
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createObject(RestObject parent, RestObject objectToCreate, Object content, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param objectUri
	 * @param params
	 * @return the sysobject of the specified uri
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getObject(String objectUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a document (or its subtype) under specified folder/cabinet
	 * 
	 * @param parent
	 *            the folder/cabinet where the new document will be created
	 *            under
	 * @param objectToCreate
	 *            the new document with its properties
	 * @param content
	 *            the binary content, it can be byte array, String,
	 *            javax.xml.transform.Source,
	 *            org.springframework.core.io.Resource, JAXB object, and Jackson
	 *            json object
	 * @param params
	 * @return the created document
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createDocument(RestObject parent, RestObject objectToCreate, Object content, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param documentUri
	 * @param params
	 * @return the document of the specified uri
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getDocument(String documentUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * update the RestObject with new properties
	 * 
	 * @param oldObject
	 *            the previously fetched RestObject
	 * @param newObject
	 *            the new RestObject with new properties to be updated
	 * @param params
	 * @return the updated RestObject
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject update(RestObject oldObject, RestObject newObject, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * update the RestObject with new properties
	 * 
	 * @param oldObject
	 * @param rel
	 * @param newObject
	 * @param method
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject update(RestObject oldObject, LinkRelation rel, RestObject newObject, HttpMethod method,
			String... params) throws TririgaDCTMIntegrationException;

	/**
	 * delete the resource
	 * 
	 * @param linkable
	 * @param params
	 * @throws TririgaDCTMIntegrationException 
	 * @throws Exception 
	 */
	public void delete(Linkable linkable, String... params) throws TririgaDCTMIntegrationException, Exception;

	/**
	 * delete thr uri
	 * 
	 * @param uri
	 * @param params
	 * @throws TririgaDCTMIntegrationException 
	 */
	public void delete(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a content (primary content or rendition) to a RestObject
	 * 
	 * @param object
	 *            the previously fetched RestObject
	 * @param content
	 *            the binary content, it can be byte array, String,
	 *            javax.xml.transform.Source,
	 *            org.springframework.core.io.Resource, JAXB object, and Jackson
	 *            json object
	 * @param mediaType
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createContent(RestObject object, Object content, String mediaType, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param object
	 * @param params
	 * @return the metadata of primary content of the specified RestObject
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getPrimaryContent(RestObject object, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param contentUri
	 * @param params
	 * @return the metadata of the content specified by the uri
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getContent(String contentUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param object
	 * @param params
	 * @return the content metadata collection
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getContents(RestObject object, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get users of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getUsers(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get users of a parent
	 * 
	 * @param parent
	 * @param rel
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getUsers(Linkable parent, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get groups of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getGroups(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single user
	 * 
	 * @param userUri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getUser(String userUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single group
	 * 
	 * @param groupUri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getGroup(String groupUri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create an user
	 * 
	 * @param userToCreate
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createUser(RestObject userToCreate) throws TririgaDCTMIntegrationException;

	/**
	 * create a group
	 * 
	 * @param groupToCreate
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createGroup(RestObject groupToCreate) throws TririgaDCTMIntegrationException;

	/**
	 * add the user to a group
	 * 
	 * @param group
	 * @param user
	 * @throws TririgaDCTMIntegrationException 
	 */
	public void addUserToGroup(RestObject group, RestObject user) throws TririgaDCTMIntegrationException;

	/**
	 * @param feed
	 *            the current page
	 * @return the next page of the feed collection if it has
	 * @throws TririgaDCTMIntegrationException 
	 */
	public <T extends Linkable> Feed<T> nextPage(Feed<T> feed) throws TririgaDCTMIntegrationException;

	/**
	 * @param feed
	 *            the current page
	 * @return the previous page of the feed collection if it has
	 * @throws TririgaDCTMIntegrationException 
	 */
	public <T extends Linkable> Feed<T> previousPage(Feed<T> feed) throws TririgaDCTMIntegrationException;

	/**
	 * @param feed
	 *            the current page
	 * @return the first page of the feed collection if it has
	 * @throws TririgaDCTMIntegrationException 
	 */
	public <T extends Linkable> Feed<T> firstPage(Feed<T> feed) throws TririgaDCTMIntegrationException;

	/**
	 * @param feed
	 *            the current page
	 * @return the last page of the feed collection if it has
	 * @throws TririgaDCTMIntegrationException 
	 */
	public <T extends Linkable> Feed<T> lastPage(Feed<T> feed) throws TririgaDCTMIntegrationException;

	/**
	 * @param object
	 * @param params
	 * @return the version histories of the given object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getVersions(RestObject object, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * check out the given RestObject (sysobject, document and their subtype)
	 * 
	 * @param object
	 * @param params
	 * @return checked out RestObject
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject checkout(RestObject object, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * cancel a checked out object
	 * 
	 * @param object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public void cancelCheckout(RestObject object) throws TririgaDCTMIntegrationException;

	/**
	 * check in the object with next major version can check in both new object
	 * metadata and binary content , or new metadata or binary content only the
	 * content can be byte array, String, javax.xml.transform.Source,
	 * org.springframework.core.io.Resource, JAXB object, and Jackson json
	 * object
	 * 
	 * @param oldObject
	 *            the checked out RestObject
	 * @param newObject
	 *            the new metadata to be checked in
	 * @param content
	 *            the binary content
	 * @param params
	 * @return checked in object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject checkinNextMajor(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * check in the object with next minor version can check in both new object
	 * metadata and binary content , or new metadata or binary content only the
	 * content can be byte array, String, javax.xml.transform.Source,
	 * org.springframework.core.io.Resource, JAXB object, and Jackson json
	 * object
	 * 
	 * @param oldObject
	 *            the checked out RestObject
	 * @param newObject
	 *            the new metadata to be checked in
	 * @param content
	 *            the binary content
	 * @param params
	 * @return checked in object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject checkinNextMinor(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * check in the object with branch version can check in both new object
	 * metadata and binary content , or new metadata or binary content only the
	 * content can be byte array, String, javax.xml.transform.Source,
	 * org.springframework.core.io.Resource, JAXB object, and Jackson json
	 * object
	 * 
	 * @param oldObject
	 *            the checked out RestObject
	 * @param newObject
	 *            the new metadata to be checked in
	 * @param content
	 *            the binary content
	 * @param params
	 * @return checked in object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject checkinBranch(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * materialize the lightweight object
	 * 
	 * @param oldObject
	 *            the object to be materialized
	 * @return materialized lightweight object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject materialize(RestObject oldObject) throws TririgaDCTMIntegrationException;

	/**
	 * dematerialize the lightweight object
	 * 
	 * @param oldObject
	 *            the object to be dematerialized
	 * @return dematerialized lightweight object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public void dematerialize(RestObject oldObject) throws TririgaDCTMIntegrationException;

	/**
	 * reparent the lightweight object to a new shared parent
	 * 
	 * @param oldObject
	 *            the object to be reparented
	 * @param newParent
	 *            the new shared parent
	 * @return reparented lightweight object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject reparent(RestObject oldObject, RestObject newParent) throws TririgaDCTMIntegrationException;

	/**
	 * get the type info
	 * 
	 * @param name
	 *            the type name
	 * @param params
	 * @return the RestType
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestType getType(String name, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param params
	 * @return the types info in the repository
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestType> getTypes(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get value assistance of a type
	 * 
	 * @param type
	 * @param request
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public ValueAssistant getValueAssistant(RestType type, ValueAssistantRequest request, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * @param params
	 * @return the aspect types info in the repository
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getAspectTypes(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get the aspect type
	 * 
	 * @param aspectType
	 * @param param
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getAspectType(String aspectType, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * attach aspects to the object
	 * 
	 * @param object
	 * @param aspects
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public ObjectAspects attach(RestObject object, String... aspects) throws TririgaDCTMIntegrationException;

	/**
	 * detach an aspect from an object
	 * 
	 * @param objectAspects
	 * @param aspect
	 * @throws TririgaDCTMIntegrationException 
	 */
	public void detach(ObjectAspects objectAspects, String aspect) throws TririgaDCTMIntegrationException;

	/**
	 * get relation types of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getRelationTypes(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single relation type
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getRelationType(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get relations of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getRelations(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single relation
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getRelation(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * create a relation
	 * 
	 * @param object
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject createRelation(RestObject object) throws TririgaDCTMIntegrationException;

	/**
	 * get formats of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getFormats(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single format
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getFormat(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get network locations of the repository
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<RestObject> getNetworkLocations(String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single network location
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject getNetworkLocation(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get folder links of the object
	 * 
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public Feed<FolderLink> getFolderLinks(RestObject object, LinkRelation rel, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * get single folder link
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public FolderLink getFolderLink(String uri, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * move the object by the folder link
	 * 
	 * @param oldLink
	 * @param newLink
	 * @param params
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public FolderLink move(FolderLink oldLink, FolderLink newLink, String... params) throws TririgaDCTMIntegrationException;

	/**
	 * link an object to another place
	 * 
	 * @param object
	 * @param rel
	 * @param link
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public FolderLink link(RestObject object, LinkRelation rel, FolderLink link) throws TririgaDCTMIntegrationException;

	/**
	 * copy a folder (or its subtype) under specified folder/cabinet
	 * 
	 * @param parent
	 *            the folder/cabinet where the new document will be created
	 *            under
	 * @param objectToCreate
	 *            the new document with its properties
	 * @return the created object
	 * @throws TririgaDCTMIntegrationException 
	 */
	public RestObject copyFolder(RestObject objectToCreate, RestObject parent) throws TririgaDCTMIntegrationException;

}
