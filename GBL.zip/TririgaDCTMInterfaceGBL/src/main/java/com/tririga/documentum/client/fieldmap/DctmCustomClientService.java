package com.tririga.documentum.client.fieldmap;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.TririgaDCTMInterface;
import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;
import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;
import com.tririga.platform.context.ContextService;
import com.tririga.platform.smartobject.domain.SmartObject;
import com.tririga.platform.smartobject.domain.field.SmartObjectFieldValueAccessor;
import com.tririga.platform.smartobject.service.SmartObjectUtils;
import com.tririga.platform.util.locator.Locator;
import com.tririga.pub.workflow.CustomParamTask;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.CustomParamTaskResultImpl;
import com.tririga.pub.workflow.Record;
import com.tririga.pub.workflow.WFStepInfoImpl;
import com.tririga.pub.workflow.WFVariable;

public class DctmCustomClientService implements CustomParamTask {

	private static Logger logger = Logger
			.getLogger(DctmCustomClientService.class);

	/**
	 * Call to create the documentum folder structure based on the object type
	 */
	public CustomParamTaskResult execute(Map parameters, long userId,
			Record[] records) {

		String dctmUrl = "";
		String tririgaBoName = "";
		String country = "";
		String boFormNameSY = "";
		String folderNameToCreate = "";
		String folderNameToUpdate = "";
		String cabinetNameToSet = "";
		String folderType = "";
		String folderNameInCabinet = "";
		String templateFolderName = "";
		String objectId = "";
		String folderObjectType = "";
		String storeNo = "";
		SmartObject smartObject = null;
		DctmClientConfigReader dctmReader = null;
		TririgaDCTMInterface dctmObj = null;
		TririgaDCTMMappingRequest dctmReq = null;
		TririgaDCTMMappingResponse dctmRes = null;
		DctmBean dctmBean = null;
		ArrayList<Long> resultRecordIds = new ArrayList<Long>();
		Properties prop = new Properties();

		// system logs params
		WFStepInfoImpl wfStepInfo = new WFStepInfoImpl();
		CustomParamTaskResultImpl taskResult = new CustomParamTaskResultImpl();
		HashMap<String, WFVariable> returnParams = new HashMap<String, WFVariable>();

		logger.info(" ******************************************* ");
		logger.info(" BEGIN EXECUTION ");
		logger.info(" ******************************************* ");

		// For retrieving mock data parameters
		logger.debug(records[0].toString());
		logger.debug(userId);
		logger.debug(parameters.toString());

		try {

			dctmReader = new DctmClientConfigReader(parameters);
			dctmBean = dctmReader.getDctmBean();
			dctmObj = new TririgaDCTMInterface();
			dctmReq = new TririgaDCTMMappingRequest();
			prop.load(TririgaDCTMHelper.class
					.getResourceAsStream("errorCodes.properties"));

			for (int i = 0; i < records.length; i++) {

				Record record = records[i];
				// To set record list in wfStepInfo
				if (i % 2 == 0) {
					resultRecordIds.add(record.getId());
				}

				smartObject = SmartObjectUtils.getSmartObject(record
						.getRecordId());

				dctmUrl = SmartObjectFieldValueAccessor.getString(smartObject
						.getField(DctmConstants.CSTDOCUMENTUMURL));
				country = SmartObjectFieldValueAccessor.getString(smartObject
						.getField(DctmConstants.CSTSYSTEMCOUNTRY));
				tririgaBoName = smartObject.getMetadata().getName();
				boFormNameSY = SmartObjectFieldValueAccessor
						.getString(smartObject
								.getField(DctmConstants.TRIFORMNAME));


				logger.info("Form Name: " + boFormNameSY);
				logger.info("BO Name: "+ tririgaBoName);
				logger.info("Country: " + country);	
				logger.info("Existing Dctm URL from Form: " + dctmUrl);

			}

			logger.info("getUrl: " + dctmBean.getUrl());		
			logger.info("getUser: " + dctmBean.getUser());
			logger.info("getDocbase: " + dctmBean.getDocbase());
			logger.info("getExtension: " + dctmBean.getExtension());
			logger.info("Cabinet Name: " + dctmBean.getCstDCTMCabinetNameTX());
			logger.info ("Folder Name in Cabinet: " + dctmBean.getCstDCTMCabFolderNameTX());			
			logger.info("Market Type: " + dctmBean.getMarketType());
			logger.info("DCTMCustFolderNameTX: " + dctmBean.getCstDCTMCustFolderNameTX());
			logger.info("StoreNo: " + dctmBean.getCstStoreNumberTX());

			cabinetNameToSet = dctmBean.getCstDCTMCabinetNameTX();
			folderNameInCabinet = dctmBean.getCstDCTMCabFolderNameTX();
			folderObjectType = dctmBean.getCstDCTMCustFolderNameTX();
			storeNo = dctmBean.getCstStoreNumberTX();


			dctmReq.setCabinetName(cabinetNameToSet);
			dctmReq.setUserId(dctmBean.getUser());
			dctmReq.setPassword(dctmBean.getPass());
			dctmReq.setFolderNameInCabinet(folderNameInCabinet);
			dctmReq.setUrl(dctmBean.getUrl());
			dctmReq.setExtension(dctmBean.getExtension());
			dctmReq.setRepos(dctmBean.getDocbase());
			dctmReq.setCustomFolderType(folderObjectType);
			dctmReq.setStoreNo(storeNo);

			if (null == dctmUrl) {
				logger.info("INSIDE CREATE FOLDER");

				dctmReq.setAction("1");
				// TODO
				logger.info("Folder Type "+dctmBean.getCstDCTMFolderTypeTX());
				folderType = dctmBean.getCstDCTMFolderTypeTX();

				if (folderType.equalsIgnoreCase(DctmConstants.COMPLEXFOLDERTYPE)) {
					dctmReq.setCopyCreateFolder(true);
				}
				if (folderType.equalsIgnoreCase(DctmConstants.SIMPLEFOLDERTYPE)) {
					dctmReq.setCopyCreateFolder(false);
				}

				// TODO
				if (!cabinetNameToSet.contains(DctmConstants.PORTFOLIOTEMPLATEFOLDER)) {
					logger.info("DCTM Cabinet Name Non Porfolio: " + cabinetNameToSet);
					if(cabinetNameToSet.contains(DctmConstants.STRING_SEPERATOR_OPENBRACKET) && cabinetNameToSet.contains(DctmConstants.STRING_SEPERATOR_CLOSEBRACKET)){
						logger.info("Fetching Template Folder Name from DCTM Cabinet Name *"+cabinetNameToSet+"*");
						templateFolderName = cabinetNameToSet.substring(0, 2)
								+ DctmConstants.STRING_SEPERATOR_SPACE
								+ cabinetNameToSet.split(DctmConstants.STRING_SEPERATOR_BACKWARDSLASH+DctmConstants.STRING_SEPERATOR_OPENBRACKET)[1].split(DctmConstants.STRING_SEPERATOR_BACKWARDSLASH+DctmConstants.STRING_SEPERATOR_CLOSEBRACKET)[0];
					}else{
						logger.info("Template Folder Name cannot be fetched since it misses short form conversion from DCTM Cabinet Name *"+cabinetNameToSet+"*");
					}
				} else {	
					logger.info("DCTM Cabinet Name Portfolio: " + cabinetNameToSet);
					templateFolderName = cabinetNameToSet;					
				}

				logger.info("Tririga Template Cabinet Name: "
						+ DctmConstants.TRIRIGATEMPLATES);
				logger.info("Tririga Template Folder Name: "
						+ templateFolderName);
				logger.info("Form Name: "
						+ boFormNameSY.trim().replace(DctmConstants.STRING_SEPERATOR_FOWARDSLASH, DctmConstants.STRING_SEPERATOR_BACKWARDSLASH));

				dctmReq.setTemplateCabinetName(DctmConstants.TRIRIGATEMPLATES);
				dctmReq.setTemplateFolderName(templateFolderName);
				dctmReq.setFormName(boFormNameSY.trim().replace(DctmConstants.STRING_SEPERATOR_FOWARDSLASH, DctmConstants.STRING_SEPERATOR_BACKWARDSLASH));				

				logger.info("Folder Name To Create: " + dctmBean.getCstDCTMFolderNameTX());
				folderNameToCreate = dctmBean.getCstDCTMFolderNameTX();
				folderNameToCreate = folderNameToCreate.trim().replace(DctmConstants.STRING_SEPERATOR_FOWARDSLASH, DctmConstants.STRING_SEPERATOR_BACKWARDSLASH);

				dctmReq.setFolderNametoCreate(folderNameToCreate);				

				logger.info("Calling Documentum to Create Folder");

				dctmRes = dctmObj.invokeDCTM(dctmReq);
				logger.info("Generated Object ID: " + dctmRes.getObjectId());

				if (dctmRes.getObjectId() != null
						|| !dctmRes.getObjectId().isEmpty()) {
					SmartObjectFieldValueAccessor.setString(smartObject
							.getField(DctmConstants.CSTDOCUMENTUMURL),
							dctmBean.getWebUrl() + dctmRes.getObjectId());
					logger.info("Folder Created Successfully");
				} else {
					SmartObjectFieldValueAccessor.setString(smartObject
							.getField(DctmConstants.DOCUMENTUM_ERROR_MSG), prop
							.getProperty("errorMessage"));
				}
			}

			if (dctmUrl != null) {
				String deleteFlag = SmartObjectFieldValueAccessor
						.getString(smartObject
								.getField(DctmConstants.CSTDELETERECORDFLAG));
				if (deleteFlag.equalsIgnoreCase(DctmConstants.DELETEFLAG)) {
					logger.info("INSIDE DELETE FOLDER");

					objectId = dctmUrl.substring(dctmUrl.lastIndexOf(DctmConstants.STRING_SEPERATOR_FOWARDSLASH) + 1);
					logger.info("ObjectId: " + objectId);

					dctmReq.setAction("6");
					dctmReq.setObjectId(objectId);

					logger.info("Calling Documentum to Delete Folder");

					dctmObj.invokeDCTM(dctmReq);
					SmartObjectFieldValueAccessor.setString(smartObject
							.getField(DctmConstants.CSTDOCUMENTUMURL), DctmConstants.STRING_EMPTY);

				} else {
					logger.info("INSIDE UPDATE FOLDER");

					objectId = dctmUrl.substring(dctmUrl.lastIndexOf(DctmConstants.STRING_SEPERATOR_FOWARDSLASH) + 1);

					logger.info("ObjectId: " + objectId);
					logger.info("New Folder Name: " + dctmBean.getCstDCTMFolderNameTX());

					folderNameToUpdate = dctmBean.getCstDCTMFolderNameTX();

					dctmReq.setNewFolderName(folderNameToUpdate);
					dctmReq.setObjectId(objectId);
					dctmReq.setAction("3");

					logger.info("Calling Documentum to Update Folder");

					dctmRes = dctmObj.invokeDCTM(dctmReq);
					// Some Forms Come to Draft state after Clicking Delete
					// Action
					// This Will clear the field so they can create the same
					// record again
					SmartObjectFieldValueAccessor.setString(smartObject
							.getField(DctmConstants.CSTDOCUMENTUMURL), dctmUrl);
					logger.info("Folder Updated Successfully");

				}
			}

			wfStepInfo.setRecordList(resultRecordIds);
			wfStepInfo.setResultCount(new Long(resultRecordIds.size()));
			wfStepInfo.setSuccess(Boolean.TRUE);
			wfStepInfo.setStatus("Custom");
			WFVariable returnParam1 = new WFVariable("folder_name", wfStepInfo);
			returnParams.put(returnParam1.getName(), returnParam1);
			taskResult.setReturnParameters(returnParams);
			taskResult.setExecutionWasSuccessful(true);
			// Clear Error Codes
			// Clear Error Message
			// If no issues encountered
			SmartObjectFieldValueAccessor.setString(
					smartObject.getField(DctmConstants.DOCUMENTUM_ERROR_MSG),
					DctmConstants.STRING_EMPTY);
			SmartObjectFieldValueAccessor.setString(
					smartObject.getField(DctmConstants.DOCUMENTUM_ERROR_CODE),
					DctmConstants.STRING_EMPTY);

			logger.info(" ***************************************** ");
			logger.info(" END EXECUTION ");
			logger.info(" ***************************************** ");

		} catch (TririgaDCTMIntegrationException e) {

			logger.info("Tririga Documentum Interface client Failed ");

			logger.info("Exception thrown:" + e.getMessage());

			SmartObjectFieldValueAccessor.setString(
					smartObject.getField(DctmConstants.DOCUMENTUM_ERROR_CODE),
					e.getMessage());

			SmartObjectFieldValueAccessor.setString(
					smartObject.getField(DctmConstants.DOCUMENTUM_ERROR_MSG),
					prop.getProperty(e.getMessage().trim()));

			synchronized (SmartObjectUtils.findCurrentContext()) {
				((ContextService) Locator.getInstance()
						.locate("contextService")).commit(SmartObjectUtils
								.findCurrentContext());
			}
		}

		catch (Exception exp) {

			logger.info("Exception thrown:" + exp.getMessage());

			StringWriter errors = new StringWriter();
			exp.printStackTrace(new PrintWriter(errors));
			logger.info(exp);

			wfStepInfo.setRecordList(resultRecordIds);
			wfStepInfo.setResultCount(new Long(resultRecordIds.size()));
			wfStepInfo.setSuccess(Boolean.FALSE);
			wfStepInfo.setStatus("Custom");
			WFVariable returnParam1 = new WFVariable("dctm", wfStepInfo);
			returnParams.put(returnParam1.getName(), returnParam1);
			taskResult.setReturnParameters(returnParams);
			taskResult.setExecutionWasSuccessful(false);

			SmartObjectFieldValueAccessor.setString(
					smartObject.getField(DctmConstants.DOCUMENTUM_ERROR_MSG),
					prop.getProperty("errorMessage"));

			synchronized (SmartObjectUtils.findCurrentContext()) {
				((ContextService) Locator.getInstance()
						.locate("contextService")).commit(SmartObjectUtils
								.findCurrentContext());
			}

		}

		return taskResult;

	}

}