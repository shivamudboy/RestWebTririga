/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model.json;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tririga.documentum.rest.client.model.InlineLinkable;
import com.tririga.documentum.rest.client.model.SearchEntry;
import com.tririga.documentum.rest.client.util.Equals;

public class JsonSearchEntry<T extends InlineLinkable> extends JsonEntry<T> implements SearchEntry<T> {
    @JsonProperty
    private String score;
    @JsonProperty
    private List<String> terms;
    
    @Override
    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    @Override
    public List<String> getTerms() {
        return terms;
    }

    public void setTerms(List<String> terms) {
        this.terms = terms;
    }

    @Override
    public boolean equals(Object obj) {
        JsonSearchEntry<?> that = (JsonSearchEntry<?>)obj;
        return super.equals(that) 
            && Equals.equal(terms, that.terms)
            && Equals.equal(score, that.score);
    }
}