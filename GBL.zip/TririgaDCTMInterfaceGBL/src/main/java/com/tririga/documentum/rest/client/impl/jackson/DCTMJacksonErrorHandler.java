/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.impl.jackson;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestClientException;
import com.tririga.documentum.rest.client.model.RestError;
import com.tririga.documentum.rest.client.model.json.JsonRestError;

/**
 * the error response handler to process json error response by Jackson
 */
public class DCTMJacksonErrorHandler implements ResponseErrorHandler {
	private final List<HttpMessageConverter<?>> converters;

	public DCTMJacksonErrorHandler(List<HttpMessageConverter<?>> converters) {
		this.converters = converters;
	}

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		return response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR ||
				response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void handleError(ClientHttpResponse response) throws IOException{
		MediaType mediaType = response.getHeaders().getContentType();
		RestError error = null;
		for(HttpMessageConverter converter : converters) {
			if(converter.canRead(JsonRestError.class, mediaType)) {
				error = (RestError)converter.read(JsonRestError.class, response);
				if(error.getStatus()==409 || (error.getStatus()==500  && 
						(error.getDetails().contains("(DM_FOLDER_E_CANT_CHANGED) [DM_FOLDER_E_CANT_CHANGED]") || 
								error.getDetails().contains("(DM_FOLDER_E_PATH_EXISTS) [DM_FOLDER_E_PATH_EXISTS]")))){
					
					throw new RestClientException(String.valueOf(error.getDetails()));				
				}
				if(error.getStatus()==400 && error.getCode().equals("E_CREATE_OBJECT_WITH_WRONG_TYPE")){					
					throw new RestClientException(error.getCode());				
				}
				break;
			}
		}
		if(error != null){
			throw new RestClientException(String.valueOf(error.getStatus()));
		}
		else{
			throw new IOException(response.toString());
		}

	}
}
