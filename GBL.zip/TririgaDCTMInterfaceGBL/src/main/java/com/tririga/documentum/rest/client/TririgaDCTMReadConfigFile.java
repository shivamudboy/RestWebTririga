/*
 * package com.tririga.documentum.rest.client; import java.util.Properties;
 * import org.apache.log4j.Logger; import
 * com.tririga.documentum.rest.client.util.ReadConfigFile; public class
 * TririgaDCTMReadConfigFile { private static Logger logger =
 * Logger.getLogger(TririgaDCTMReadConfigFile.class);
 *//**
 * (non-Javadoc)
 * 
 * @see
 */
/*
 * public boolean readConfigFile() { Properties configProperties =
 * ReadConfigFile.getConfigProperties();
 * logger.info("************* Reading Config File Start ********************");
 * // get the property value and print it out
 * logger.info(configProperties.getProperty("dbUrl"));
 * logger.info(configProperties.getProperty("dbDriver"));
 * logger.info(configProperties.getProperty("dbUser"));
 * logger.info(configProperties.getProperty("dbPass")); // get the property
 * value and print it out
 * logger.info(configProperties.getProperty("contextRoot"));
 * logger.info(configProperties.getProperty("repository"));
 * logger.info(configProperties.getProperty("username"));
 * logger.info(configProperties.getProperty("password"));
 * logger.info(configProperties.getProperty("useFormatExtension"));
 * logger.info(configProperties.getProperty("debug"));
 * logger.info("************* Reading Config File End ********************");
 * return true; } }
 */