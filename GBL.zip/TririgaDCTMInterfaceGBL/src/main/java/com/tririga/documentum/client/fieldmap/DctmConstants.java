package com.tririga.documentum.client.fieldmap;

public interface DctmConstants {

	
	public final static String DCTM_USER = "cstDCTMUserTX";
	public final static String DCTM_PASS = "cstDCTMPasswordTX";
	public final static String DCTM_DOCBASE = "cstDCTMDocBaseTX";
	public final static String DCTM_RESTURL = "cstDCTMRESTURLTX";
	public final static String DCTM_EXTN = "cstDCTMFormatExtensionTX";
	public final static String DCTM_WEBTOP = "cstWebTopURL";
	public final static String DCTM_MARKETTYPE = "cstMarketTypeTX";
	public final static String DCTM_TRIRIGA = "dctm_tririga";	
	public final static String DCTM_INTERFACE_FIELD_MAP = "dctm_interface_field_map";
	public final static String DCTM_BINDING =  "JSON";
		
	public final static String STRING_SEPERATOR_PIPE =  "|";
	public final static String STRING_SEPERATOR_SPACE =  " ";
	public final static String STRING_SEPERATOR_FOWARDSLASH =  "/";
	public final static String STRING_SEPERATOR_BACKWARDSLASH =  "\\";
	public final static String STRING_SEPERATOR_OPENBRACKET =  "(";
	public final static String STRING_SEPERATOR_CLOSEBRACKET =  ")";
	public final static String STRING_SEPERATOR_COMMA =  ",";
	public final static String STRING_EMPTY = "";
	
	public final static String TRIRIGATEMPLATES =  "TririgaTemplates";	
	public final static String SIMPLEFOLDERTYPE =  "Simple";
	public final static String COMPLEXFOLDERTYPE =  "Complex";	
	public final static String DELETEFLAG =  "TRUE";
	public final static String PORTFOLIOTEMPLATEFOLDER =  "Portfolio";
	public final static String TRIFORMNAME = "triFormNameSY";
	public final static String CSTDELETERECORDFLAG ="cstDeleteRecordBL";	
	public final static String CSTDOCUMENTUMURL =  "cstDocumentumURL";
	public final static String CSTSYSTEMCOUNTRY =  "cstSystemCountryTX";
	public final static String CST_STORE_NUMBER = "cstFolderField1TX";
	public final static String DOCUMENTUM_ERROR_MSG = "cstDCTMDevErrorMsgTX";
	public final static String DOCUMENTUM_ERROR_CODE ="cstDCTMErrorCodeTX";	
	
	public final static int HUNDRED_NUMBER =  100;
	
	//dctm_interface_field_map BO fields
	public final static String DCTM_CABINET_NAME = "cstDCTMCabinetNameTX";
	public final static String DCTM_CAB_FOLDER_NAME = "cstDCTMCabFolderNameTX";
	public final static String DCTM_FOLDER_NAME = "cstDCTMFolderNameTX";
	public final static String DCTM_FOLDER_TYPE = "cstDCTMFolderTypeTX";
	public final static String DCTM_CUST_FOLDER_NAME = "cstDCTMCustFolderNameTX";

		
	
}
