/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model;

import java.util.List;

/**
 * the object which is linkable
 */
public interface Linkable {
    /**
     * @return all the links provided by the resource
     */
    List<Link> getLinks();
    
    /**
     * @param rel
     * @return specified link by relation
     */
    String getHref(LinkRelation rel);
    
    /**
     * @param rel
     * @param title
     * @return specified link by relation and title
     */
    String getHref(LinkRelation rel, String title);
    
    /**
     * @return self link
     */
    String self();
}
