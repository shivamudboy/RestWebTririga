/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model;

import java.util.List;

public interface ObjectAspects extends Linkable {
    public List<String> getAspects();
}
