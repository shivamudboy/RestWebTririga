package com.tririga.documentum.rest.client.util;


import java.io.IOException;
import java.security.Key;
import java.util.Base64;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.DCTMRestClient;
import com.tririga.documentum.rest.client.DCTMRestClientBinding;
import com.tririga.documentum.rest.client.DCTMRestClientBuilder;
import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.model.Entry;
import com.tririga.documentum.rest.client.model.Feed;
import com.tririga.documentum.rest.client.model.FolderLink;
import com.tririga.documentum.rest.client.model.LinkRelation;
import com.tririga.documentum.rest.client.model.PlainFolderLink;
import com.tririga.documentum.rest.client.model.PlainRestObject;
import com.tririga.documentum.rest.client.model.RestObject;
import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;

public class TririgaDCTMHelper
{

	private static Logger logger = Logger.getLogger(TririgaDCTMHelper.class);
	private static DCTMRestClient client;
	private static Cipher cipher;
	private static Properties prop = new Properties();
	static{
		try {
			prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Method to connect to Documentum Server(via REST Services) using the
	 * Configuration details received from TRIRIGA
	 * 
	 * @param request
	 * @throws TririgaDCTMIntegrationException
	 */
	public static void configDctmClient(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException, Exception
	{

		String bindingStr = "JSON";
		Boolean debug = false;
		String decryptedPassword = null;
		DCTMRestClientBuilder builder = null;
		DCTMRestClientBinding binding = DCTMRestClientBinding.valueOf(bindingStr.toUpperCase());


		if(request.getUrl() == null || request.getUrl().isEmpty())
		{
			logger.info("URL is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullURL"));
		} 
		else if(request.getRepos() == null || request.getRepos().isEmpty())
		{
			logger.info("Repository is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullRepository"));
		}
		else if(request.getUserId() == null || request.getUserId().isEmpty())
		{
			logger.info("UserId is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullUserId"));
		}
		else if(request.getPassword() == null || request.getPassword().isEmpty())
		{
			logger.info("Password is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullPassword"));
		}
		else
		{	
			String inputPwd = request.getPassword().trim();
			decryptedPassword =  ((inputPwd.endsWith("==")) ? decrypt(inputPwd):inputPwd) ;

			builder = new DCTMRestClientBuilder().bind(binding).contextRoot(request.getUrl())
					.credentials(request.getUserId(), decryptedPassword).repository(request.getRepos())
					.useFormatExtension("true".equalsIgnoreCase(request.getExtension())).debug(debug);

		}

		client = builder.build();		

	}

	/**
	 * Update the Folder Name based on Object Id and FolderName
	 * 
	 * @param newFolderName
	 * @param folderUrl
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	private static RestObject updateOnObjIdString(String newFolderName, String folderUrl,String customFolderType,String storeNo) throws TririgaDCTMIntegrationException
	{
		logger.info("--updateOnObjIdString() process started--");
		RestObject updateFolderName;
		RestObject updatedFolder;
		RestObject srcFolderName = client.getFolder(folderUrl);
		logger.info("FolderName before Update " + srcFolderName.getProperties().get("object_name"));
		if (customFolderType != null)
		{			
			if(customFolderType.trim().equals("wm_us_pm_folder"))
			{							
				logger.info("Applying Store No *"+storeNo+"* for customFolderType *"+customFolderType+"*");
				if(storeNo != null && !storeNo.isEmpty() && storeNo.chars().allMatch(Character::isDigit))
				{						
					updateFolderName = new PlainRestObject("object_name", newFolderName, "wm_fld_store_number", Integer.parseInt(storeNo));
				}
				else
				{
					logger.info("Store No is Invalid and unable to set it for custom folder type *"+customFolderType+"*");
					throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidStoreNo"));
				}
			}
			else
			{
				updateFolderName = new PlainRestObject("object_name", newFolderName);
			}
		}
		else
		{
			logger.info("Custom Folder Type is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullCustFolType"));
		}		

		updatedFolder = client.update(srcFolderName, updateFolderName);
		logger.info("--updateOnObjIdString() process ended--");
		return updatedFolder;
	}

	/**
	 * Update the folder name based on ObjectId
	 * 
	 * @param request
	 * @param folderUrl
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public static String updateOnObjId(TririgaDCTMMappingRequest request, String folderUrl, String newFolderName) throws TririgaDCTMIntegrationException,Exception
	{
		logger.info("--updateOnObjId() process started--");
		String updatedObjName;
		String customFolderType = request.getCustomFolderType();
		String storeNo = request.getStoreNo();		
		RestObject updateFolderName;
		RestObject updatedFolder;	
		RestObject srcFolderName = client.getFolder(folderUrl);
		
		if(newFolderName == null || newFolderName.isEmpty())
		{
			logger.info("New Folder Name to Update is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullNewFolderName"));
		}
		
		logger.info("--DCTM Session Established--");
		
		logger.info("FolderName before Update " + srcFolderName.getProperties().get("object_name"));

		if (customFolderType != null)
		{			
			if(customFolderType.trim().equals("wm_us_pm_folder"))
			{							
				logger.info("Applying Store No *"+storeNo+"* for customFolderType *"+customFolderType+"*");
				if(storeNo != null && !storeNo.isEmpty() && storeNo.chars().allMatch(Character::isDigit))
				{						
					updateFolderName = new PlainRestObject("object_name", newFolderName, "wm_fld_store_number", Integer.parseInt(storeNo));
				}
				else
				{
					logger.info("Store No is Invalid and unable to set it for custom folder type *"+customFolderType+"*");
					throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidStoreNo"));
				}
			}
			else
			{
				updateFolderName = new PlainRestObject("object_name", newFolderName);
			}
		}
		else
		{
			logger.info("Custom Folder Type is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullCustFolType"));
		}	


		updatedFolder = client.update(srcFolderName, updateFolderName);
		if(updatedFolder == null)
		{			
			RestObject cabinet = null;
			String strFolderNameInCabinet = request.getFolderNameInCabinet();
			String strCabinetName = request.getCabinetName();
			if (strFolderNameInCabinet.isEmpty())
			{
				cabinet = client.getCabinet(strCabinetName);				
			}
			else
			{
				Feed<RestObject> cabFolders = client.getFolders(client.getCabinet(strCabinetName));
				for (Entry<RestObject> entries : cabFolders.getEntries())
				{												
					if (strFolderNameInCabinet.equals(entries.getTitle().trim()))
					{
						cabinet = client.getFolder(entries.getContentSrc());
						break;
					}
				}			
			}

			String objId = folderSearch(cabinet, request.getNewFolderName());
			if(objId != null){
				logger.info("New Folder name to update already exists inside Cabinet *"+strCabinetName+"*");			
				throw new TririgaDCTMIntegrationException(prop.getProperty("FolderAlreadyExist"));
			}			
		}

		updatedObjName = updatedFolder.getProperties().get("object_name").toString();

		logger.info("FolderName After Update " + updatedObjName);

		logger.info("--updateOnObjId() process ended--");
		return updatedObjName;
	}

	/**
	 * Update the folder name based on Folder and Cabinet Name
	 * 
	 * @param request
	 * @param e
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	public static String updateFolder(TririgaDCTMMappingRequest request, Entry<RestObject> e) throws TririgaDCTMIntegrationException
	{
		String updatedObjId;
		RestObject updateFolderName;
		RestObject updatedFolder;
		RestObject srcFolderName = client.getFolder(e.getContentSrc());
		logger.debug("srcFolderName.obj_name " + srcFolderName.getProperties().get("object_name"));
		updateFolderName = new PlainRestObject("object_name", request.getNewFolderName());
		updatedFolder = client.update(srcFolderName, updateFolderName);
		updatedObjId = updatedFolder.getProperties().get("r_object_id").toString();
		logger.debug("r_object_id=" + updatedObjId + " object_name=" + updatedFolder.getProperties().get("object_name"));
		return updatedObjId;
	}

	/**
	 * Method to read the Create New Folders based on Cabinet and Folder.
	 * 
	 * @param strCabinet
	 * @param strFolderName
	 * @param strFolderNameInCabinet
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public static TririgaDCTMMappingResponse create(String strCabinet, String strFolderName,
			String strFolderNameInCabinet,String customFolderType,String storeNo) throws TririgaDCTMIntegrationException, Exception
	{

		logger.info("--Inside create()--");
		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();

		RestObject strDestinationFolder = null;
		RestObject newFolder = null;
		boolean isFolderNameInCabinet = false;

		//Replace / to \ in order to avoid folder creation error 
		strFolderNameInCabinet = strFolderNameInCabinet.replace("/", "\\");
		strFolderName = strFolderName.replace("/", "\\");

		logger.info("Getting Cabinet to Create Folder");
		RestObject cabinetObj = client.getCabinet(strCabinet);
		if (null == cabinetObj)
		{
			logger.info("Invalid CabinetName in Request *"+strCabinet+"*");
			throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidCabinetName"));
		}

		logger.info("--DCTM Session Established--");		

		// Create Folders Directly in given Cabinet
		if (strFolderNameInCabinet.isEmpty())
		{
			logger.info("Creating Folder Inside Cabinet *" + strCabinet+"*");
			// Applying CustomFolder Type
			if (customFolderType != null)
			{
				logger.info("Applying CustomFolderType *" + customFolderType+"*");
				if(customFolderType.trim().equals("wm_us_pm_folder"))
				{							
					logger.info("Applying Store No *"+storeNo+"* for customFolderType *"+customFolderType+"*");
					if(storeNo != null && !storeNo.isEmpty() && storeNo.chars().allMatch(Character::isDigit))
					{						
						newFolder = new PlainRestObject("object_name", strFolderName, "wm_fld_store_number", Integer.parseInt(storeNo) , "r_object_type", customFolderType);
					}
					else
					{
						logger.info("Store No is Invalid and unable to set it for custom folder type *"+customFolderType+"*");
						throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidStoreNo"));
					}
				}
				else
				{
					newFolder = new PlainRestObject("object_name", strFolderName, "r_object_type", customFolderType);
				}
			}
			else
			{
				logger.info("Custom Folder Type is NULL/Empty in Request");
				throw new TririgaDCTMIntegrationException(prop.getProperty("NullCustFolType"));
			}

			strDestinationFolder = client.createFolder(cabinetObj, newFolder);
			if(null == strDestinationFolder)
			{
				String objId = folderSearch(cabinetObj, strFolderName);
				if(objId != null){
					logger.info("FolderNameToCreate *"+strFolderName+"* already exist in Cabinet *"+strCabinet+"*");				
					response.setObjectId(objId);
					return response;
				}
			}
		}

		// Create Folders in mentioned Folders present inside a Cabinet
		else
		{
			logger.info("Creating SubFolder Inside *" + strFolderNameInCabinet + "* In Cabinet *" + strCabinet
					+ "*");

			logger.info("Fetching Folders of Cabinet *"+strCabinet+"*");
			Feed<RestObject> folders = client.getFolders(cabinetObj);

			logger.info("Searching for Folder *"+strFolderNameInCabinet+"* inside *"+strCabinet+"* Cabinet");
			if(folders.getEntries() != null){
				for (Entry<RestObject> e : folders.getEntries())
				{					
					if (strFolderNameInCabinet.equals(e.getTitle().trim()))
					{						
						logger.info("Inside *" + strFolderNameInCabinet + "* to create NewFolder");
						isFolderNameInCabinet = true;
						RestObject subParent = client.getFolder(e.getContentSrc());

						if (customFolderType != null)
						{
							logger.info("Applying CustomFolderType *" + customFolderType+"*");
							if(customFolderType.trim().equals("wm_us_pm_folder"))
							{	
								logger.info("Applying Store No *"+storeNo+"* for customFolderType *"+customFolderType+"*");
								if(storeNo != null && !storeNo.isEmpty() && storeNo.chars().allMatch(Character::isDigit))
								{
									newFolder = new PlainRestObject("object_name", strFolderName, "wm_fld_store_number", Integer.parseInt(storeNo) , "r_object_type", customFolderType);
								}
								else
								{
									logger.info("Store No is Invalid and unable to set it for custom folder type *"+customFolderType+"*");
									throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidStoreNo"));
								}
							}
							else
							{
								newFolder = new PlainRestObject("object_name", strFolderName, "r_object_type", customFolderType);
							}
						}
						else
						{
							logger.info("Custom Folder Type is NULL/Empty in Request");
							throw new TririgaDCTMIntegrationException(prop.getProperty("NullCustFolType"));
						}

						strDestinationFolder = client.createFolder(subParent, newFolder);
						if(null == strDestinationFolder)
						{
							String objId = folderSearch(subParent, strFolderName);
							if(objId != null){
								logger.info("FolderNameToCreate *"+strFolderName+"* already exist in Cabinet *"+strCabinet+"*");				
								response.setObjectId(objId);
								return response;
							}
							break;
						}
					}
				}
			}
			if(!isFolderNameInCabinet){
				logger.info("*" + strFolderNameInCabinet + "* is Not Found Inside *" + strCabinet + "* Cabinet");
				throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidFolderName"));
			}
		}

		logger.info("NewFolder *" + strFolderName + "* Created with Id "
				+ strDestinationFolder.getProperties().get("r_object_id").toString());
		response.setObjectId(strDestinationFolder.getProperties().get("r_object_id").toString());

		return response;

	}

	/**
	 * Method to read the Template Cabinet to read the required project and
	 * folders and create a new Folder.
	 * 
	 * @param strCabinet
	 * @param strFolderName
	 * @param strFormName
	 * @param strTemplateFolder
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public static TririgaDCTMMappingResponse copyRenameFolder(TririgaDCTMMappingRequest request)
			throws TririgaDCTMIntegrationException, Exception
	{

		logger.info("--Inside copyRenameFolder()--");
		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();

		String strCabinet = request.getCabinetName();
		String strFolderName = request.getFolderNametoCreate();
		String strFormName = request.getFormName();
		String strTemplateFolder = request.getTemplateFolderName();
		String strFolderNameInCabinet = request.getFolderNameInCabinet();
		String strTemplateCabinet = request.getTemplateCabinetName();
		boolean isFormName = false;
		boolean isTemplateFolderName = false;
		boolean isFolderNameInCabinet = false;

		RestObject copiedContent = null;
		RestObject cabinetObj = null;
		RestObject subFolder = null;

		//Replace / to \ in order to avoid folder creation error 
		strFolderNameInCabinet = strFolderNameInCabinet.replace("/", "\\");
		strFolderName = strFolderName.replace("/", "\\");

		//Get Template Cabinet for processing
		logger.info("Getting Template Cabinet to Copy Folder");
		RestObject strTemplateCabinetObj = client.getCabinet(strTemplateCabinet);

		logger.info("--DCTM Session Established--");

		logger.info("Fetching Folders of Template Cabinet *"+strTemplateCabinet+"*");
		Feed<RestObject> folders = client.getFolders(strTemplateCabinetObj);

		logger.info("Searching for Template Folder *"+strTemplateFolder+"* inside *"+strTemplateCabinet+"* Cabinet");
		if(folders.getEntries() != null){
			for (Entry<RestObject> e : folders.getEntries())
			{
				if (strTemplateFolder.equals(e.getTitle().trim()))
				{					
					logger.info("Found *" + strTemplateFolder + "* Folder Inside *" + strTemplateCabinet + "* Cabinet");
					isTemplateFolderName = true;

					// look for required folder to copy them to new location
					RestObject parent = client.getFolder(e.getContentSrc());

					logger.info("Fetching Folders of Template Folder *"+strTemplateFolder+"*");
					Feed<RestObject> subParent = client.getFolders(parent);

					logger.info("Searching for Form *"+strFormName+"* inside *"+strTemplateFolder+"* Folder");
					if(subParent.getEntries() != null){
						for (Entry<RestObject> e1 : subParent.getEntries())
						{							
							if (strFormName.equals(e1.getTitle().trim()))
							{

								logger.info("Found *" + strFormName + "* Inside *" + strTemplateFolder + "* Folder");
								isFormName = true;

								cabinetObj = client.getCabinet(strCabinet);
								if(null == cabinetObj)
								{
									logger.info("Invalid CabinetName in Request *" +strCabinet+"*");
									throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidCabinetName"));
								}
								else
								{
									// Copy Folders To Destination Cabinet
									if (strFolderNameInCabinet.isEmpty())
									{
										// Create FoldersDirectly in DestinationCabinet
										logger.info("Creating Folder under Cabinet *" + strCabinet+"*");
										copiedContent = client.copyFolder(cabinetObj, client.getFolder(e1.getContentSrc()));
										break;
									}
									else
									{
										// Search for Folder in DestinationCabinet
										logger.info("Fetching Folders of Destination Cabinet *"+strCabinet+"*");
										Feed<RestObject> destFolders = client.getFolders(cabinetObj);

										logger.info("Searching for Destination Folder *"+strFolderNameInCabinet+"* inside *"+strCabinet+"* Cabinet");
										if(destFolders.getEntries() != null){
											for (Entry<RestObject> entries : destFolders.getEntries())
											{												
												if (strFolderNameInCabinet.equals(entries.getTitle().trim()))
												{
													logger.info("Inside Destination Folder *" + strFolderNameInCabinet + "*");
													isFolderNameInCabinet = true;													
													subFolder = client.getFolder(entries.getContentSrc());										
													copiedContent = client.copyFolder(subFolder,
															client.getFolder(e1.getContentSrc()));
													break;
												}


											}
										}
										if(!isFolderNameInCabinet){
											logger.info("*" + strFolderNameInCabinet + "* is Not Found Inside *" + strCabinet + "* Cabinet");
											throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidFolderName"));
										}
									}
								}							
								break;
							}						
						}
					}
					if(!isFormName){
						logger.info("FormName *"+strFormName+"* is Not Found TemplateFolder *"+ strTemplateFolder + "*");
						throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidFormName"));
					}
					break;
				}

			}
		}
		if(!isTemplateFolderName){
			logger.info("TemplateFolder *"+strTemplateFolder+"* is Not Found Inside the TemplateCabinet *"+strTemplateCabinet+"*");
			throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidTemplateFolder"));
		}
		// Invoke Update() to renameFolder as per Tririga

		logger.info("Calling updateFolderName()");
		String newObjectId = copiedContent.getProperties().get("r_object_id").toString();
		String folderUrl = request.getUrl() + "repositories/" + request.getRepos() + "/folders/" + newObjectId;	

		RestObject updatedFolder = updateOnObjIdString(strFolderName, folderUrl, request.getCustomFolderType(), request.getStoreNo());

		if(updatedFolder == null)
		{						
			RestObject cabinet = null;
			if (strFolderNameInCabinet.isEmpty())
			{
				cabinet = cabinetObj;				
			}
			else
			{
				cabinet = subFolder;				
			}

			String objId = folderSearch(cabinet, strFolderName);
			if(objId != null){
				logger.info("FolderName to create already exists inside Cabinet *"+strCabinet+"*");
				RestObject FolderName = client.getFolder(folderUrl);
				client.delete(FolderName,"del-non-empty", "true");	
				response.setObjectId(objId);				
				return response;
			}
		}

		logger.info("Destination Folder r_object_id= " + updatedFolder.getProperties().get("r_object_id")
				+ " ; r_folder_path= " + updatedFolder.getProperties().get("r_folder_path"));

		response.setObjectId(newObjectId);

		return response;

	}

	/**
	 * Method to move the folders from Active Projects to Archive Location
	 * 
	 * @param strCabinet
	 * @param strFolderName
	 * @param strFolderNameInCabinet
	 * @param strFolderNameAtArchive
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public static TririgaDCTMMappingResponse moveFolders(String strCabinet, String strFolderName,
			String strFolderNameInCabinet, String strFolderNameAtArchive) throws TririgaDCTMIntegrationException, Exception
	{

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();
		String strArchiveCabinetName = "Archive"; // Fixed Cabinet for Archive
		RestObject archiveParent = null;
		FolderLink movedLink = null;
		boolean isFolderNameAtArchive = false;
		boolean isFolderNameInCabinet = false;
		boolean isFolderNametoMove = false;

		// Get the folderLinks for Archive Folder
		RestObject strArchiveCabinetObj = client.getCabinet(strArchiveCabinetName);
		if(null == strArchiveCabinetObj)
		{
			logger.info("Archive Cabinet not Found");
			throw new TririgaDCTMIntegrationException("DCT-1024");
		}

		logger.info("--DCTM Session Established--");

		Feed<RestObject> folderStr = client.getFolders(strArchiveCabinetObj);
		// We need to code again 2 logics to search for folders directly inside
		// cabinet and folders inside the cabinet
		for (Entry<RestObject> e1 : folderStr.getEntries())
		{
			if (strFolderNameAtArchive.isEmpty())
			{
				archiveParent = strArchiveCabinetObj;
				break;
			}
			else
			{
				logger.info("Folders inside Archive = " + e1.getTitle().trim() + " -> " + e1.getContentSrc());
				if (strFolderNameAtArchive.equals(e1.getTitle().trim()))
				{
					isFolderNameAtArchive = true;
					logger.info("Inside Folder to Copy the src = " + e1.getTitle().trim() + " -> " + e1.getContentSrc());
					archiveParent = client.getFolder(e1.getContentSrc());
					break;
				}
			}
		}
		if(!isFolderNameAtArchive){
			logger.info("*" + strFolderNameAtArchive + "* ArchiveFolder is Not Found Inside ArchiveCabinet *" + strArchiveCabinetName + "*");
			throw new TririgaDCTMIntegrationException("DCT-1025");
		}

		// Get Folders to Move from Source Location to Archive
		RestObject strCabinetToSearch = client.getCabinet(strCabinet);
		if (null == strCabinetToSearch)
		{
			logger.info("Invalid CabinetName in Request *"+strCabinet+"*");
			throw new TririgaDCTMIntegrationException("DCT-1012");
		}

		else {
			Feed<RestObject> folders = client.getFolders(strCabinetToSearch);

			for (Entry<RestObject> e : folders.getEntries())
			{
				logger.info("Folder Inside Required Cabinet = " + e.getTitle().trim() + " -> " + e.getContentSrc());
				// Move Folders Directly in given Cabinet
				if (strFolderNameInCabinet.isEmpty())
				{
					if (strFolderName.equals(e.getTitle().trim()))
					{
						isFolderNametoMove = true;
						logger.info("Folder to Move = " + e.getTitle().trim() + " -> " + e.getContentSrc());
						RestObject srcObjToMove = client.getFolder(e.getContentSrc());

						Feed<FolderLink> parentFolderLinks = client.getFolderLinks(srcObjToMove, LinkRelation.PARENT_LINKS);
						logger.info("parentFolderLinks getSrc = " + parentFolderLinks.getEntries().get(0).getContentSrc());
						FolderLink parentLinkToBeMove = client.getFolderLink(parentFolderLinks.getEntries().get(0)
								.getContentSrc());

						movedLink = client.move(parentLinkToBeMove, new PlainFolderLink(archiveParent.self()));
						logger.info("href:" + movedLink.getHref() + ", parent id:" + movedLink.getParentId()
								+ ", child id:" + movedLink.getChildId());
						break;
					}

				}
				// Move Folders in mentioned Folders present inside a Cabinet
				else
				{
					if (strFolderNameInCabinet.equals(e.getTitle().trim()))
					{
						isFolderNameInCabinet = true;
						logger.info("Found Folder = " + e.getTitle().trim() + " -> " + e.getContentSrc());

						// look for required folder to copy them to new location
						RestObject parent = client.getFolder(e.getContentSrc());
						Feed<RestObject> subParent = client.getFolders(parent);
						for (Entry<RestObject> e12 : subParent.getEntries())
						{
							logger.info("Found Folders e1 = " + e12.getTitle().trim() + " -> " + e12.getContentSrc());
							if (strFolderName.equals(e12.getTitle().trim()))
							{
								isFolderNametoMove = true;
								logger.info("Inside Required Folder = " + e12.getTitle().trim() + " -> "
										+ e12.getContentSrc());
								RestObject srcObjToMove = client.getFolder(e12.getContentSrc());

								Feed<FolderLink> parentFolderLinks = client.getFolderLinks(srcObjToMove,
										LinkRelation.PARENT_LINKS);
								logger.info("parentFolderLinks getSrc = "
										+ parentFolderLinks.getEntries().get(0).getContentSrc());
								FolderLink parentLinkToBeMove = client.getFolderLink(parentFolderLinks.getEntries().get(0)
										.getContentSrc());

								movedLink = client.move(parentLinkToBeMove, new PlainFolderLink(archiveParent.self()));
								logger.info("href:" + movedLink.getHref() + ", parent id:" + movedLink.getParentId()
										+ ", child id:" + movedLink.getChildId());
								break;
							}
						}
					}
					break;
				}
			}
			if(!isFolderNameInCabinet){
				logger.info("*" + strFolderNameInCabinet + "* is Not Found Inside *" + strCabinet + "* Cabinet");
				throw new TririgaDCTMIntegrationException("DCT-1002");
			}

			if(!isFolderNametoMove){
				logger.info("*" + strFolderName + "* is Not Found Inside *" + strCabinet + "* Cabinet");
				throw new TririgaDCTMIntegrationException("DCT-1026");
			}
		}
		response.setUpdatedObjId(movedLink.getHref());
		return response;
	}



	/**
	 * Method to Decrypt password using JDK and AES
	 * 
	 * @param encryptedText
	 * @return
	 * @throws TririgaDCTMIntegrationException
	 * @throws Exception
	 */
	private static String decrypt(String encryptedText) throws TririgaDCTMIntegrationException, Exception
	{
		cipher = Cipher.getInstance("AES");

		String key = "f#6kn$46uv*q9%t7"; // junk key
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");

		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(encryptedText);
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);
		return decryptedText;
	}

	/**
	 * Method to delete a folder based on Object Id of folder
	 * 
	 * @param folderUrl
	 * @throws TririgaDCTMIntegrationException, Exception
	 */

	public static void deleteFolder(TririgaDCTMMappingRequest request,String folderUrl) throws TririgaDCTMIntegrationException, Exception 
	{
		logger.info("--DCTM Session Established--");		
		RestObject FolderName = client.getFolder(folderUrl);
		client.delete(FolderName,"del-non-empty", "true");		
		logger.info("--Folder " + request.getObjectId()+" deleted successfully--");

	}
	public static String folderSearch(RestObject cabinetObj,String folderToCreate) throws TririgaDCTMIntegrationException,Exception
	{

		Feed<RestObject> folders = client.getFolders(cabinetObj);	
		String objId = null;

		if(folders.getEntries() != null){
			for (Entry<RestObject> e1 : folders.getEntries())
			{
				if (folderToCreate.equals(e1.getTitle().trim()))
				{
					objId = e1.getSummary().split(" ")[1];					
					break;
				}
			}
		}

		return objId;		

	}

}
