/**
 * 
 */

package com.tririga.documentum.rest.client.response;

public class TririgaDCTMMappingResponse
{

	// Variable for Create()
	private String objectId;
	// Variable for Update()
	private String updatedObjId;
	// Variable for Archive()
	private String movedObjLink;

	/**
	 * @return the movedObjLink
	 */
	public String getMovedObjLink()
	{
		return movedObjLink;
	}

	/**
	 * @param movedObjLink
	 *            the movedObjLink to set
	 */
	public void setMovedObjLink(String movedObjLink)
	{
		this.movedObjLink = movedObjLink;
	}

	/**
	 * @return the objectId
	 */
	public String getObjectId()
	{
		return objectId;
	}

	/**
	 * @param objectId
	 *            the objectId to set
	 */
	public void setObjectId(String objectId)
	{
		this.objectId = objectId;
	}

	/**
	 * @return the updatedObjId
	 */
	public String getUpdatedObjId()
	{
		return updatedObjId;
	}

	/**
	 * @param updatedObjId
	 *            the updatedObjId to set
	 */
	public void setUpdatedObjId(String updatedObjId)
	{
		this.updatedObjId = updatedObjId;
	}

}
