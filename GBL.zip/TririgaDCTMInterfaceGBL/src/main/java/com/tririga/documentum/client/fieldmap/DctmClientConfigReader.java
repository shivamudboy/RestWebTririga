package com.tririga.documentum.client.fieldmap;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;
import com.tririga.platform.smartobject.domain.SmartObject;
import com.tririga.platform.smartobject.domain.field.SmartObjectFieldValueAccessor;
import com.tririga.platform.smartobject.service.SmartObjectUtils;
import com.tririga.pub.workflow.WFStepInfo;
import com.tririga.pub.workflow.WFVariable;

public class DctmClientConfigReader {

	private static Logger logger = Logger
			.getLogger(DctmClientConfigReader.class);

	private DctmBean bean;

	public DctmClientConfigReader(Map parameters)
			throws TririgaDCTMIntegrationException, IOException {
		setDctmParams(parameters);
	}

	public void setDctmParams(Map parameters)
			throws TririgaDCTMIntegrationException, IOException {
		Properties prop = new Properties();
		logger.info("Inside DctmClientConfigReader()");
		
		logger.info(" BEGIN SET DOCUMENTUM CREDENTIALS ");

		Collection<SmartObject> dctmTririga = getParameterSmartObjects(parameters,
				DctmConstants.DCTM_TRIRIGA);		
		Collection<SmartObject> dctmInterfaceFieldMap = getParameterSmartObjects(parameters,
				DctmConstants.DCTM_INTERFACE_FIELD_MAP);

		prop.load(TririgaDCTMHelper.class
				.getResourceAsStream("errorCodes.properties"));

		if (dctmTririga.size() > 0 || dctmInterfaceFieldMap.size() > 0) {
			bean = new DctmBean();
			for (SmartObject so : dctmTririga) {

				if (so != null) {
					bean.setDocbase(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_DOCBASE)));
					bean.setUser(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_USER)));
					bean.setPass(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_PASS)));
					bean.setUrl(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_RESTURL)));
					bean.setExtension(SmartObjectFieldValueAccessor
							.getString(so.getField(DctmConstants.DCTM_EXTN)));
					bean.setWebUrl(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_WEBTOP)));
					bean.setMarketType(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.DCTM_MARKETTYPE)));
				} else {
					throw new TririgaDCTMIntegrationException(
							prop.getProperty("NullSmartObject"));
				}
			}		

			for (SmartObject so : dctmInterfaceFieldMap) {

				if (so != null) {
					bean.setCstDCTMCabinetNameTX(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.DCTM_CABINET_NAME)));
					bean.setCstDCTMCabFolderNameTX(SmartObjectFieldValueAccessor.getString(so
							.getField(DctmConstants.DCTM_CAB_FOLDER_NAME)));
					bean.setCstDCTMFolderNameTX(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.DCTM_FOLDER_NAME)));
					bean.setCstDCTMFolderTypeTX(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.DCTM_FOLDER_TYPE)));
					bean.setCstDCTMCustFolderNameTX(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.DCTM_CUST_FOLDER_NAME)));
					bean.setCstStoreNumberTX(SmartObjectFieldValueAccessor
							.getString(so
									.getField(DctmConstants.CST_STORE_NUMBER)));
				} else {
					throw new TririgaDCTMIntegrationException(
							prop.getProperty("NullSmartObject"));
				}
			}

		}

		this.setDctmBean(bean);

		logger.info(" END SET DOCUMENTUM CREDENTIALS ");
	}

	public Collection<SmartObject> getParameterSmartObjects(Map params,
			String name) {

		logger.info(" BEGIN getParameterSmartObjects ");

		ArrayList<SmartObject> result = new ArrayList<SmartObject>();
		WFVariable targetTasksVar = (WFVariable) params.get(name);

		if (targetTasksVar != null) {
			WFStepInfo targetTaskStepInfo = (WFStepInfo) targetTasksVar
					.getValue();

			Collection resultIds = targetTaskStepInfo.getResultRecordIds();
			logger.info("Result size for Workflow Parameter: " + resultIds.size());

			for (Iterator<Long> iter = resultIds.iterator(); iter.hasNext();) {

				result.add(SmartObjectUtils.getSmartObject(iter.next()
						.longValue()));
			}

		} else {
			logger.error("No such parameter '" + name + "' found");
		}

		logger.info(" END getParameterSmartObjects ");
		return (result);
	}

	public DctmBean getDctmBean() {
		return this.bean;
	}

	public void setDctmBean(DctmBean bean) {
		this.bean = bean;
	}

}
