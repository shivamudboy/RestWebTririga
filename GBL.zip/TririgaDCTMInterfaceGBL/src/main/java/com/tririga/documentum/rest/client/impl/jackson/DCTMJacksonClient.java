/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */

package com.tririga.documentum.rest.client.impl.jackson;

import static com.tririga.documentum.rest.client.model.LinkRelation.ABOUT;
import static com.tririga.documentum.rest.client.model.LinkRelation.ASPECT_TYPES;
import static com.tririga.documentum.rest.client.model.LinkRelation.ASSIS_VALUES;
import static com.tririga.documentum.rest.client.model.LinkRelation.CABINETS;
import static com.tririga.documentum.rest.client.model.LinkRelation.CANCEL_CHECKOUT;
import static com.tririga.documentum.rest.client.model.LinkRelation.CHECKIN_BRANCH_VERSION;
import static com.tririga.documentum.rest.client.model.LinkRelation.CHECKIN_NEXT_MAJOR;
import static com.tririga.documentum.rest.client.model.LinkRelation.CHECKIN_NEXT_MINOR;
import static com.tririga.documentum.rest.client.model.LinkRelation.CHECKOUT;
import static com.tririga.documentum.rest.client.model.LinkRelation.CONTENTS;
import static com.tririga.documentum.rest.client.model.LinkRelation.DELETE;
import static com.tririga.documentum.rest.client.model.LinkRelation.DEMATERIALIZE;
import static com.tririga.documentum.rest.client.model.LinkRelation.DOCUMENTS;
import static com.tririga.documentum.rest.client.model.LinkRelation.EDIT;
import static com.tririga.documentum.rest.client.model.LinkRelation.FOLDERS;
import static com.tririga.documentum.rest.client.model.LinkRelation.FORMATS;
import static com.tririga.documentum.rest.client.model.LinkRelation.GROUPS;
import static com.tririga.documentum.rest.client.model.LinkRelation.MATERIALIZE;
import static com.tririga.documentum.rest.client.model.LinkRelation.NETWORK_LOCATIONS;
import static com.tririga.documentum.rest.client.model.LinkRelation.OBJECTS;
import static com.tririga.documentum.rest.client.model.LinkRelation.OBJECT_ASPECTS;
import static com.tririga.documentum.rest.client.model.LinkRelation.PAGING_FIRST;
import static com.tririga.documentum.rest.client.model.LinkRelation.PAGING_LAST;
import static com.tririga.documentum.rest.client.model.LinkRelation.PAGING_NEXT;
import static com.tririga.documentum.rest.client.model.LinkRelation.PAGING_PREV;
import static com.tririga.documentum.rest.client.model.LinkRelation.PRIMARY_CONTENT;
import static com.tririga.documentum.rest.client.model.LinkRelation.RELATIONS;
import static com.tririga.documentum.rest.client.model.LinkRelation.RELATION_TYPES;
import static com.tririga.documentum.rest.client.model.LinkRelation.REPOSITORIES;
import static com.tririga.documentum.rest.client.model.LinkRelation.SEARCH;
import static com.tririga.documentum.rest.client.model.LinkRelation.SELF;
import static com.tririga.documentum.rest.client.model.LinkRelation.SHARED_PARENT;
import static com.tririga.documentum.rest.client.model.LinkRelation.TYPES;
import static com.tririga.documentum.rest.client.model.LinkRelation.USERS;
import static com.tririga.documentum.rest.client.model.LinkRelation.VERSIONS;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Properties;

import javax.annotation.concurrent.NotThreadSafe;

import org.apache.log4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.tririga.documentum.rest.client.DCTMRestClient;
import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.impl.AbstractRestTemplateClient;
import com.tririga.documentum.rest.client.model.Entry;
import com.tririga.documentum.rest.client.model.Feed;
import com.tririga.documentum.rest.client.model.FolderLink;
import com.tririga.documentum.rest.client.model.HomeDocument;
import com.tririga.documentum.rest.client.model.LinkRelation;
import com.tririga.documentum.rest.client.model.Linkable;
import com.tririga.documentum.rest.client.model.ObjectAspects;
import com.tririga.documentum.rest.client.model.Repository;
import com.tririga.documentum.rest.client.model.RestObject;
import com.tririga.documentum.rest.client.model.RestType;
import com.tririga.documentum.rest.client.model.SearchFeed;
import com.tririga.documentum.rest.client.model.ValueAssistant;
import com.tririga.documentum.rest.client.model.ValueAssistantRequest;
import com.tririga.documentum.rest.client.model.json.JsonFeeds;
import com.tririga.documentum.rest.client.model.json.JsonFolderLink;
import com.tririga.documentum.rest.client.model.json.JsonHomeDocument;
import com.tririga.documentum.rest.client.model.json.JsonObject;
import com.tririga.documentum.rest.client.model.json.JsonObjectAspects;
import com.tririga.documentum.rest.client.model.json.JsonRepository;
import com.tririga.documentum.rest.client.model.json.JsonType;
import com.tririga.documentum.rest.client.model.json.JsonValueAssistance;
import com.tririga.documentum.rest.client.model.json.JsonValueAssistantRequest;
import com.tririga.documentum.rest.client.util.Headers;
import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;
import com.tririga.documentum.rest.client.util.UriHelper;

/**
 * the DCTMRestClient implementation by Jackson json support
 */
@NotThreadSafe
public class DCTMJacksonClient extends AbstractRestTemplateClient implements DCTMRestClient
{
	private static Logger logger = Logger.getLogger(DCTMJacksonClient.class);
	private static Properties prop = new Properties();
	
	public DCTMJacksonClient(String contextRoot, String repositoryName, String username, String password,
			boolean useFormatExtension) throws TririgaDCTMIntegrationException
	{
		super(contextRoot, repositoryName, username, password, useFormatExtension);
	}

	@Override
	public HomeDocument getHomeDocument() throws TririgaDCTMIntegrationException
	{
		if (homeDocument == null)
		{
			homeDocument = get(getHomeDocumentUri(), Headers.ACCEPT_JSON_HOME_DOCUMENT, JsonHomeDocument.class);
		}
		return homeDocument;
	}

	@Override
	public RestObject getProductInfo() throws TririgaDCTMIntegrationException
	{
		if (productInfo == null)
		{
			productInfo = get(getHomeDocument().getHref(ABOUT), false, JsonObject.class);
		}
		return productInfo;
	}

	@Override
	public Feed<Repository> getRepositories() throws TririgaDCTMIntegrationException
	{
		if (repositories == null)
		{
			String repositoriesUri = getHomeDocument().getHref(REPOSITORIES);
			Feed<? extends Repository> feed = get(repositoriesUri, true, JsonFeeds.RepositoryFeed.class);
			repositories = (Feed<Repository>) feed;
		}
		return repositories;
	}

	@Override
	public Repository getRepository() throws TririgaDCTMIntegrationException
	{
		try 
		{
			prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));
			if(prop == null)
			{
				throw new TririgaDCTMIntegrationException("Property file load is failed");
			}
		} 
		catch (IOException e1) {			
			e1.printStackTrace();
		}
		if (repository == null)
		{
			boolean resetEnableStreaming = enableStreaming;
			boolean repoCheck = false;
			Feed<Repository> repositories = getRepositories();
			for (Entry<Repository> e : repositories.getEntries())
			{
				if (repositoryName != null && repositoryName.equals(e.getTitle()))
				{
					repository = get(e.getContentSrc(), false, JsonRepository.class);
					repoCheck = true;
				}

			}
			if(!repoCheck)
			{
				logger.info("Invalid Repository *"+repositoryName+"*");
				throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidRepository"));
			}
			if (resetEnableStreaming)
			{
				enableStreaming = resetEnableStreaming;
			}
		}
		return repository;
	}

	@Override
	public Feed<RestObject> dql(String dql, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(SELF), true, JsonFeeds.ObjectFeed.class,
				UriHelper.append(params, "dql", dql));
		return (Feed<RestObject>) feed;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SearchFeed<RestObject> search(String search, String... params) throws TririgaDCTMIntegrationException
	{
		SearchFeed<? extends RestObject> feed = get(getRepository().getHref(SEARCH), true, JsonFeeds.SearchFeed.class,
				UriHelper.append(params, "q", search));
		return (SearchFeed<RestObject>) feed;
	}

	@Override
	public Feed<RestObject> getCabinets(String... params) throws TririgaDCTMIntegrationException
	{
		Repository repository = getRepository();
		String cabinetsUri = repository.getHref(CABINETS);
		Feed<? extends RestObject> feed = get(cabinetsUri, true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getCabinet(String cabinet, String... params) throws TririgaDCTMIntegrationException
	{
		RestObject obj = null;
		Feed<RestObject> feed = getCabinets("filter", "starts-with(object_name,'" + cabinet + "')");
		List<Entry<RestObject>> entries = feed.getEntries();
		if (entries != null)
		{
			for (Entry<RestObject> e : (List<Entry<RestObject>>) entries)
			{
				if (cabinet.equals(e.getTitle()))
				{
					obj = get(e.getContentSrc(), false, JsonObject.class);					
					break;
				}
			}
		}
		
		return obj;
	}

	@Override
	public RestObject get(RestObject object, String... params) throws TririgaDCTMIntegrationException
	{
		return get(object.getHref(SELF), false, object.getClass(), params);
	}

	@Override
	public Feed<RestObject> getFolders(RestObject parent, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(parent.getHref(FOLDERS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public Feed<RestObject> getObjects(RestObject parent, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(parent.getHref(OBJECTS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public Feed<RestObject> getDocuments(RestObject parent, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(parent.getHref(DOCUMENTS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject createFolder(RestObject parent, RestObject newFolder, String... params) throws TririgaDCTMIntegrationException
	{
		return post(parent.getHref(FOLDERS), new JsonObject(newFolder), JsonObject.class, params);
	}

	@Override
	public RestObject getFolder(String folderUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(folderUri, false, JsonObject.class, params);
	}

	@Override
	public RestObject createObject(RestObject parent, LinkRelation rel, RestObject objectToCreate, Object content,
			String... params) throws TririgaDCTMIntegrationException
	{
		return post(parent.getHref(rel), new JsonObject(objectToCreate), content, JsonObject.class, params);
	}

	@Override
	public RestObject getObject(String objectUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(objectUri, false, JsonObject.class, params);
	}

	@Override
	public RestObject createDocument(RestObject parent, RestObject objectToCreate, Object content, String... params) throws TririgaDCTMIntegrationException
	{
		return post(parent.getHref(DOCUMENTS), new JsonObject(objectToCreate), content, JsonObject.class, params);
	}

	@Override
	public RestObject getDocument(String documentUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(documentUri, false, JsonObject.class, params);
	}

	@Override
	public RestObject update(RestObject oldObject, RestObject newObject, String... params) throws TririgaDCTMIntegrationException
	{
		return update(oldObject, EDIT, newObject, HttpMethod.POST, params);
	}

	@Override
	public RestObject createContent(RestObject object, Object content, String mediaType, String... params) throws TririgaDCTMIntegrationException
	{
		return post(object.getHref(CONTENTS), content, mediaType, JsonObject.class, params);
	}

	@Override
	public RestObject getPrimaryContent(RestObject object, String... params) throws TririgaDCTMIntegrationException
	{
		return getContent(object.getHref(PRIMARY_CONTENT), params);
	}

	@Override
	public RestObject getContent(String contentUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(contentUri, false, JsonObject.class, params);
	}

	@Override
	public Feed<RestObject> getContents(RestObject object, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(object.getHref(CONTENTS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject checkout(RestObject object, String... params) throws TririgaDCTMIntegrationException
	{
		return put(object.getHref(CHECKOUT), JsonObject.class, params);
	}

	@Override
	public void cancelCheckout(RestObject object) throws TririgaDCTMIntegrationException
	{
		delete(object.getHref(CANCEL_CHECKOUT));
	}

	@Override
	public RestObject checkinNextMajor(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException
	{
		return checkin(oldObject, CHECKIN_NEXT_MAJOR, newObject, content, params);
	}

	@Override
	public RestObject checkinNextMinor(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException
	{
		return checkin(oldObject, CHECKIN_NEXT_MINOR, newObject, content, params);
	}

	@Override
	public RestObject checkinBranch(RestObject oldObject, RestObject newObject, Object content, String... params) throws TririgaDCTMIntegrationException
	{
		return checkin(oldObject, CHECKIN_BRANCH_VERSION, newObject, content, params);
	}

	@Override
	public Feed<RestObject> getVersions(RestObject object, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(object.getHref(VERSIONS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject materialize(RestObject oldObject) throws TririgaDCTMIntegrationException
	{
		return put(oldObject.getHref(MATERIALIZE), JsonObject.class);
	}

	@Override
	public void dematerialize(RestObject oldObject) throws TririgaDCTMIntegrationException
	{
		delete(oldObject.getHref(DEMATERIALIZE));
	}

	@Override
	public RestObject reparent(RestObject oldObject, RestObject newParent) throws TririgaDCTMIntegrationException
	{
		JsonObject parent = new JsonObject();
		parent.setHref(newParent.getHref(SELF));
		return post(oldObject.getHref(SHARED_PARENT), parent, JsonObject.class);
	}

	@Override
	public RestType getType(String name, String... params) throws TririgaDCTMIntegrationException
	{
		return get(getRepository().getHref(TYPES) + "/" + name, false, JsonType.class, params);
	}

	@Override
	public Feed<RestType> getTypes(String... params) throws TririgaDCTMIntegrationException
	{
		Repository repository = getRepository();
		String typesUri = repository.getHref(TYPES);
		Feed<? extends RestType> feed = get(typesUri, true, JsonFeeds.TypeFeed.class, params);
		return (Feed<RestType>) feed;
	}

	@Override
	public Feed<RestObject> getAspectTypes(String... params) throws TririgaDCTMIntegrationException
	{
		Repository repository = getRepository();
		String aspectTypesUri = repository.getHref(ASPECT_TYPES);
		Feed<? extends RestObject> feed = get(aspectTypesUri, true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getAspectType(String aspectType, String... params) throws TririgaDCTMIntegrationException
	{
		return get(getRepository().getHref(ASPECT_TYPES) + "/" + aspectType, false, JsonObject.class, params);
	}

	@Override
	public ValueAssistant getValueAssistant(RestType type, ValueAssistantRequest request, String... params) throws TririgaDCTMIntegrationException
	{
		return post(type.getHref(ASSIS_VALUES), new JsonValueAssistantRequest(request), JsonValueAssistance.class,
				params);
	}

	@Override
	public ObjectAspects attach(RestObject object, String... aspects) throws TririgaDCTMIntegrationException
	{
		return post(object.getHref(OBJECT_ASPECTS), new JsonObjectAspects(aspects), JsonObjectAspects.class);
	}

	@Override
	public void detach(ObjectAspects objectAspects, String aspect) throws TririgaDCTMIntegrationException
	{
		delete(objectAspects.getHref(DELETE, aspect));
	}

	@Override
	public Feed<RestObject> getUsers(String... params) throws TririgaDCTMIntegrationException
	{
		return getUsers(getRepository(), params);
	}

	@Override
	public Feed<RestObject> getUsers(Linkable parent, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(parent.getHref(USERS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public Feed<RestObject> getGroups(String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(GROUPS), true, JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getUser(String userUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(userUri, false, JsonObject.class, params);
	}

	@Override
	public RestObject getGroup(String groupUri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(groupUri, false, JsonObject.class, params);
	}

	@Override
	public RestObject createUser(RestObject userToCreate) throws TririgaDCTMIntegrationException
	{
		return post(getRepository().getHref(USERS), new JsonObject(userToCreate), JsonObject.class);
	}

	@Override
	public RestObject createGroup(RestObject groupToCreate) throws TririgaDCTMIntegrationException
	{
		return post(getRepository().getHref(GROUPS), new JsonObject(groupToCreate), JsonObject.class);
	}

	@Override
	public void addUserToGroup(RestObject group, RestObject user) throws TririgaDCTMIntegrationException
	{
		JsonObject groupUser = new JsonObject();
		groupUser.setHref(user.getHref(SELF));
		post(group.getHref(USERS), groupUser, null);
	}

	@Override
	public Feed<RestObject> getRelationTypes(String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(RELATION_TYPES), true,
				JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getRelationType(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, JsonObject.class, params);
	}

	@Override
	public Feed<RestObject> getRelations(String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(RELATIONS), true, JsonFeeds.ObjectFeed.class,
				params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getRelation(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, JsonObject.class, params);
	}

	@Override
	public RestObject createRelation(RestObject object) throws TririgaDCTMIntegrationException
	{
		return post(getRepository().getHref(RELATIONS), new JsonObject(object), JsonObject.class);
	}

	@Override
	public Feed<RestObject> getFormats(String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(FORMATS), true, JsonFeeds.ObjectFeed.class,
				params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getFormat(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, JsonObject.class, params);
	}

	@Override
	public Feed<RestObject> getNetworkLocations(String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends RestObject> feed = get(getRepository().getHref(NETWORK_LOCATIONS), true,
				JsonFeeds.ObjectFeed.class, params);
		return (Feed<RestObject>) feed;
	}

	@Override
	public RestObject getNetworkLocation(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, JsonObject.class, params);
	}

	@Override
	public Feed<FolderLink> getFolderLinks(RestObject object, LinkRelation rel, String... params) throws TririgaDCTMIntegrationException
	{
		Feed<? extends FolderLink> feed = get(object.getHref(rel), true, JsonFeeds.FolderLinkFeed.class, params);
		return (Feed<FolderLink>) feed;
	}

	@Override
	public FolderLink getFolderLink(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, JsonFolderLink.class, params);
	}

	@Override
	public FolderLink move(FolderLink oldLink, FolderLink newLink, String... params) throws TririgaDCTMIntegrationException
	{
		return put(oldLink.getHref(SELF), new JsonFolderLink(newLink), JsonFolderLink.class, params);
	}

	@Override
	public FolderLink link(RestObject object, LinkRelation rel, FolderLink link) throws TririgaDCTMIntegrationException
	{
		return post(object.getHref(rel), new JsonFolderLink(link), JsonFolderLink.class);
	}

	@Override
	public <T extends Linkable> Feed<T> nextPage(Feed<T> feed) throws TririgaDCTMIntegrationException
	{
		return page(feed.getHref(PAGING_NEXT), feed.getClass());
	}

	@Override
	public <T extends Linkable> Feed<T> previousPage(Feed<T> feed) throws TririgaDCTMIntegrationException
	{
		return page(feed.getHref(PAGING_PREV), feed.getClass());
	}

	@Override
	public <T extends Linkable> Feed<T> firstPage(Feed<T> feed) throws TririgaDCTMIntegrationException
	{
		return page(feed.getHref(PAGING_FIRST), feed.getClass());
	}

	@Override
	public <T extends Linkable> Feed<T> lastPage(Feed<T> feed) throws TririgaDCTMIntegrationException
	{
		return page(feed.getHref(PAGING_LAST), feed.getClass());
	}

	private <T extends Linkable> Feed<T> page(String uri, Class<? extends Feed> clazz) throws TririgaDCTMIntegrationException
	{
		Feed<T> feed = null;
		if (uri != null)
		{
			feed = get(uri, true, clazz);
		}
		return feed;
	}

	private RestObject checkin(RestObject oldObject, LinkRelation rel, RestObject newObject, Object content,
			String... params) throws TririgaDCTMIntegrationException
	{
		RestObject resp = null;
		if (newObject != null && content != null)
		{
			resp = post(oldObject.getHref(rel), new JsonObject(newObject), content, JsonObject.class, params);
		}
		else if (newObject == null)
		{
			resp = post(oldObject.getHref(rel), content, MediaType.APPLICATION_OCTET_STREAM_VALUE,
					oldObject.getClass(), params);
		}
		else if (content == null)
		{
			resp = post(oldObject.getHref(rel), new JsonObject(newObject), JsonObject.class, params);
		}
		return resp;
	}

	@Override
	protected void initRestTemplate(RestTemplate restTemplate) throws TririgaDCTMIntegrationException
	{
		restTemplate.setErrorHandler(new DCTMJacksonErrorHandler(restTemplate.getMessageConverters()));
		for (HttpMessageConverter<?> c : restTemplate.getMessageConverters())
		{
			if (c instanceof MappingJackson2HttpMessageConverter)
			{
				((MappingJackson2HttpMessageConverter) c).getObjectMapper().setSerializationInclusion(
						JsonInclude.Include.NON_EMPTY);
				// ((MappingJackson2HttpMessageConverter)c).getObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				// false);
			}
			else if (c instanceof FormHttpMessageConverter)
			{
				try
				{
					Field pcField = FormHttpMessageConverter.class.getDeclaredField("partConverters");
					pcField.setAccessible(true);
					List<HttpMessageConverter<?>> partConverters = (List<HttpMessageConverter<?>>) pcField.get(c);
					for (HttpMessageConverter<?> pc : partConverters)
					{
						if (pc instanceof MappingJackson2HttpMessageConverter)
						{
							((MappingJackson2HttpMessageConverter) pc).getObjectMapper().setSerializationInclusion(
									JsonInclude.Include.NON_EMPTY);
							// ((MappingJackson2HttpMessageConverter)pc).getObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
							// false);
							break;
						}
					}
				}
				catch(Exception e)
				{
					throw new IllegalStateException(e);
				}
			}
		}
	}

	@Override
	protected ClientType getClientType()
	{
		return ClientType.JSON;
	}

	/**
	 * POST to Destination OBJ Link and Source can be Object/Document/Folder
	 */
	@Override
	public RestObject copyFolder(RestObject destinationobject, RestObject sourceObject) throws TririgaDCTMIntegrationException
	{
		return postCopy(destinationobject.getHref(LinkRelation.OBJECTS), sourceObject.getHref(LinkRelation.OBJECTS),
				JsonObject.class);
	}

}
