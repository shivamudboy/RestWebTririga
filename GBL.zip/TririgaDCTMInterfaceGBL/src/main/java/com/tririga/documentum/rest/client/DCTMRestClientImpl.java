
package com.tririga.documentum.rest.client;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;
import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;

public class DCTMRestClientImpl
{
	private static Logger logger = Logger.getLogger(DCTMRestClientImpl.class);
	private static Properties prop = new Properties();

	/**
	 * Invoke appropriate method based on Boolean and select either Defined
	 * Template for folder creation or create a folder directly inside a cabinet
	 * 
	 * @param request
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse createFoldersInDCTM(TririgaDCTMMappingRequest request)
			throws TririgaDCTMIntegrationException, Exception
	{
		logger.info("--createFoldersInDCTM() process started--");

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();
		prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));		

		if(request.getCabinetName() == null || request.getCabinetName().isEmpty())
		{
			logger.info("CabinetName is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullCabinetName")); 
		}
		else if(request.getFolderNameInCabinet() == null)
		{
			logger.info("FolderNameInCabinet is NULL in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullFolderNameInCabinet"));
		}
		else if(request.getFolderNametoCreate() == null || request.getFolderNametoCreate().isEmpty())
		{
			logger.info("FolderNameToCreate is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullFolderNameToCreate")); 
		}
		else
		{
			if (request.isCopyCreateFolder())
			{	// For Creating Complex Folder like capitalProject/triBuilding/cstBundleBid

				if(request.getTemplateFolderName() == null || request.getTemplateFolderName().isEmpty())
				{
					logger.info("TemplateFolderName is NULL/Empty in Request");
					throw new TririgaDCTMIntegrationException(prop.getProperty("NullTemplateFolderName"));
				}
				else if(request.getFormName() == null || request.getFormName().isEmpty())
				{
					logger.info("FormName is NULL/Empty in Request");
					throw new TririgaDCTMIntegrationException(prop.getProperty("NullFormName")); 
				}
				else
				{
					response = copyRenameFolders(request);
				}
			}
			else
			{
				response = createFolders(request);
			}
		}

		logger.info("--createFoldersInDCTM() process ended--");
		return response;
	}

	/**
	 * Create Folders based on Tririga need i.e Directly in given Cabinet or
	 * under mentioned Folders
	 * 
	 * @param request
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse createFolders(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException,
	Exception
	{
		logger.info("--createFolders() process started--");

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();

		TririgaDCTMHelper.configDctmClient(request);				

		response = TririgaDCTMHelper.create(request.getCabinetName(), request.getFolderNametoCreate(),
				request.getFolderNameInCabinet(),request.getCustomFolderType(),request.getStoreNo());

		logger.info("--createFolders() process ended--");
		return response;
	}

	/**
	 * Method to update the existing folder names based on request params
	 * 
	 * @param req
	 * @return strUpdatedObjId
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse lookupandUpdate(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException, 
	Exception
	{
		logger.info("--lookupandUpdate() process started--");

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();
		String strUpdatedObjId = null;
		String strObjId = request.getObjectId();
		String newFolderName = request.getNewFolderName();
		prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));
		if(null == strObjId || strObjId.isEmpty())
		{
			logger.info("ObjectID is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullObjId"));
		}
		
		if(newFolderName == null || newFolderName.isEmpty())
		{
			logger.info("New Folder Name to Update is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullNewFolderName"));
		}
		else 
		{			
			logger.info("Object Id: "+strObjId);

			TririgaDCTMHelper.configDctmClient(request);

			// Update the folder name based on ObjectId
			String folderUrl = request.getUrl() + "repositories/" + request.getRepos() + "/folders/"
					+ request.getObjectId();

			logger.info("folderUrl based on ObjId " + folderUrl);
			strUpdatedObjId = TririgaDCTMHelper.updateOnObjId(request, folderUrl, newFolderName);

			response.setUpdatedObjId(strUpdatedObjId);
		}

		logger.info("--lookupandUpdate() process ended--");
		return response;

	}

	/**
	 * @param request
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse copyRenameFolders(TririgaDCTMMappingRequest request)
			throws TririgaDCTMIntegrationException, Exception
	{	

		logger.info("--copyRenameFolders() process started--");

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();

		TririgaDCTMHelper.configDctmClient(request);

		response = TririgaDCTMHelper.copyRenameFolder(request);

		logger.info("--copyRenameFolders() process ended--");

		return response;
	}

	/**
	 * Copy Folders from Template Cabinet and Create Folders inside required
	 * Cabinet
	 * 
	 * @param request
	 * @return TririgaDCTMMappingResponse
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse archiveFolders(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException,
	Exception
	{
		logger.info("--archiveFolders in Documentum process started--");

		TririgaDCTMMappingResponse response = new TririgaDCTMMappingResponse();		

		TririgaDCTMHelper.configDctmClient(request);

		response = TririgaDCTMHelper.moveFolders(request.getCabinetName(), request.getFolderNametoMove(),
				request.getFolderNameInCabinet(), request.getFolderNameAtArchive());

		logger.info("--archiveFolders in Documentum process ended--");

		return response;
	}

	/**
	 * Method to delete Folders based on ObjectId
	 * 
	 * @param request
	 * @throws TririgaDCTMIntegrationException
	 */
	public void deleteFolders(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException,Exception
	{
		logger.info("--deleteFolders() process started-- ");
		String strObjId = request.getObjectId();
		prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));
		if(null == strObjId || strObjId.isEmpty())
		{
			logger.info("ObjectID is NULL/Empty in Request");
			throw new TririgaDCTMIntegrationException(prop.getProperty("NullObjId"));
		} 
		else 
		{

			logger.info("Object Id: "+strObjId);

			TririgaDCTMHelper.configDctmClient(request);

			String folderUrl = request.getUrl() + "repositories/"
					+ request.getRepos() + "/folders/" + strObjId.trim();

			logger.debug("FolderDRL " + folderUrl);

			TririgaDCTMHelper.deleteFolder(request, folderUrl);

		}
		logger.info("--deleteFolders() process ended--");
	}

}
