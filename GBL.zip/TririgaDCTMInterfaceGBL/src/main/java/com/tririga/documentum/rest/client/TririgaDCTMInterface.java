
package com.tririga.documentum.rest.client;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;

public class TririgaDCTMInterface
{
	private static TririgaDCTMMappingResponse response;
	private static Logger logger = Logger.getLogger(TririgaDCTMInterface.class);

	/**
	 * Method invoked from TRIRIGA to connect to Documentum and create folders.
	 * Various methods are invoked based on request/action Type.
	 * 
	 * @param request
	 * @return
	 * @throws TririgaDCTMIntegrationException
	 */
	public TririgaDCTMMappingResponse invokeDCTM(TririgaDCTMMappingRequest request) throws TririgaDCTMIntegrationException,
			Exception
	{
		logger.info("***Tririga Documentum Interface Started***");
		long startTime = System.nanoTime();
		DCTMRestClientImpl clientImpl = new DCTMRestClientImpl();
		int action = Integer.parseInt(request.getAction());

		switch(action)
		{
		// Only Case 1 in use
			case 1:
				logger.info("Calling createFoldersInDCTM()");
				response = clientImpl.createFoldersInDCTM(request);
				break;
			case 2:
				logger.info("Calling CreateFolder() to Return SingleFolder ObjectId");
				response = clientImpl.createFolders(request);
				break;
			case 3:
				logger.info("Calling Lookup() to Update FolderName");
				response = clientImpl.lookupandUpdate(request);
				break;
			case 4:
				logger.info("Calling Archive()");
				response = clientImpl.archiveFolders(request);
				break;
			case 5:
				logger.info("Calling copyRenameFolders() to Create Complex FolderStructure");
				response = clientImpl.copyRenameFolders(request);
				break;
			case 6 :
				logger.info("Calling DeleteFolderOnObjId()");
				clientImpl.deleteFolders(request);
				break;
			default:
				logger.info("Undefined Method");
				System.exit(0);
				break;
		}
		long endTime = System.nanoTime();
		long elapsedTime = endTime - startTime;
		logger.info("***Tririga Documentum Interface Completed In *** " + (elapsedTime / 1000000) * 0.001 + " Secs");

		return response;
	}

}