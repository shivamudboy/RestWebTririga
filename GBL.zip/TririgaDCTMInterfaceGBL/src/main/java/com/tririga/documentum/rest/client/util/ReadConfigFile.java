/*
 * package com.tririga.documentum.rest.client.util; import
 * java.io.FileInputStream; import java.io.IOException; import
 * java.io.InputStream; import java.util.Properties; import
 * org.apache.log4j.Logger; import
 * com.tririga.documentum.rest.client.DCTMRestClientImpl; public class
 * ReadConfigFile {
 *//** The logger. */
/*
 * private static Logger logger = Logger.getLogger(DCTMRestClientImpl.class);
 * public static void main(String args[]) { Properties prop =
 * getConfigProperties(); } public static Properties getConfigProperties() {
 * Properties prop = new Properties(); InputStream input = null; try {
 * logger.info("********In getConfigProperties()*************"); // input = new
 * // FileInputStream("src/main/resources/config.properties"); input = new
 * FileInputStream("config.properties"); // load a properties file
 * prop.load(input); // get the property value and print it out
 * logger.info("dbUrl = " + prop.getProperty("dbUrl"));
 * logger.info("dbDriver = " + prop.getProperty("dbDriver"));
 * logger.info("dbUser = " + prop.getProperty("dbUser"));
 * logger.info("dbPass = " + prop.getProperty("dbPass")); // get the property
 * value and print it out logger.info("contextRoot = " +
 * prop.getProperty("contextRoot")); logger.info("repository = " +
 * prop.getProperty("repository")); logger.info("username = " +
 * prop.getProperty("username")); logger.info("password = " +
 * prop.getProperty("password")); logger.info("useFormatExtension = " +
 * prop.getProperty("useFormatExtension")); logger.info("debug = " +
 * prop.getProperty("debug")); } catch(IOException ex) { ex.printStackTrace(); }
 * finally { if (input != null) { try { input.close(); } catch(IOException e) {
 * e.printStackTrace(); } } } return prop; } }
 */