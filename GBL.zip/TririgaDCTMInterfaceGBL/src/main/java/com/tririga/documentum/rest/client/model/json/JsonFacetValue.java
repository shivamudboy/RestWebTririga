/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model.json;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tririga.documentum.rest.client.model.Facet;
import com.tririga.documentum.rest.client.model.FacetValue;
import com.tririga.documentum.rest.client.util.Equals;

public class JsonFacetValue extends JsonInlineLinkableBase implements FacetValue {
    @JsonProperty("facet-id")
    private String facetId;
    @JsonProperty("facet-value-id")
    private String id;
    @JsonProperty("facet-value-count")
    private int count;
    @JsonProperty("facet-value-constraint")
    private String constraint;
    @JsonProperty
    private List<JsonFacet> facets;

    @Override
    public String getFacetId() {
        return facetId;
    }

    public void setFacetId(String facetId) {
        this.facetId = facetId;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String getConstraint() {
        return constraint;
    }

    public void setConstraint(String constraint) {
        this.constraint = constraint;
    }

    @Override
    public List<Facet> getFacets() {
        return facets==null?null:new ArrayList<Facet>(facets);
    }

    public void setFacets(List<JsonFacet> facets) {
        this.facets = facets;
    }

    @Override
    public boolean equals(Object obj) {
        JsonFacetValue that = (JsonFacetValue) obj;
        return Equals.equal(facetId, that.facetId)
                && Equals.equal(id, that.id)
                && Equals.equal(count, that.count)
                && Equals.equal(constraint, that.constraint);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(facetId, id, count, constraint);
    }
}
