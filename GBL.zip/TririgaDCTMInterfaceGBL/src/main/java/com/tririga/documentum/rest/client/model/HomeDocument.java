/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model;

/**
 * represents Home Document provided by REST server
 */
public interface HomeDocument extends Linkable {
}
