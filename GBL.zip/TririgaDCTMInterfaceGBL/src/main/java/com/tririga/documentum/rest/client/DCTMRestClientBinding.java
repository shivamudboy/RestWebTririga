/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client;

/**
 * the client binding type.
 * Support both XML and Json binding
 */
public enum DCTMRestClientBinding {
    XML, JSON
}
