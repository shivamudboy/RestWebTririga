/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */

package com.tririga.documentum.rest.client.impl;

import static com.tririga.documentum.rest.client.model.LinkRelation.DELETE;
import static com.tririga.documentum.rest.client.model.LinkRelation.EDIT;
import static com.tririga.documentum.rest.client.model.LinkRelation.SELF;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.concurrent.NotThreadSafe;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.tririga.documentum.rest.client.DCTMRestClient;
import com.tririga.documentum.rest.client.exception.TririgaDCTMIntegrationException;
import com.tririga.documentum.rest.client.model.Feed;
import com.tririga.documentum.rest.client.model.HomeDocument;
import com.tririga.documentum.rest.client.model.LinkRelation;
import com.tririga.documentum.rest.client.model.Linkable;
import com.tririga.documentum.rest.client.model.Repository;
import com.tririga.documentum.rest.client.model.RestObject;
import com.tririga.documentum.rest.client.util.Debug;
import com.tririga.documentum.rest.client.util.Headers;
import com.tririga.documentum.rest.client.util.SupportedMediaTypes;
import com.tririga.documentum.rest.client.util.TririgaDCTMHelper;
import com.tririga.documentum.rest.client.util.UriHelper;

/**
 * the basic implementation with Spring RestTemplate
 */
@NotThreadSafe
public abstract class AbstractRestTemplateClient implements DCTMRestClient
{
	protected final RestTemplate restTemplate = new RestTemplate();

	protected final String contextRoot;
	protected final boolean useFormatExtension;
	protected final String repositoryName;
	protected final String username;
	protected final String password;
	protected HomeDocument homeDocument;
	protected RestObject productInfo;
	protected Feed<Repository> repositories;
	protected Repository repository;
	protected boolean enableStreaming = false;
	protected boolean debug;

	protected HttpHeaders headers;
	protected HttpStatus status;
	private static Properties prop = new Properties();

	private static Logger logger = Logger.getLogger(AbstractRestTemplateClient.class);
	private static String trustStore = "javax.net.ssl.trustStore";
	private static String trustStorePassword = "javax.net.ssl.trustStorePassword";
	private static String trustStoreFormat = "javax.net.ssl.trustStoreType";
	private static String trustStorePath = "/JDKs_WinSCP/jdk1.8.0_25/jre/lib/security/cacerts";
	private static String trustStorePasswordValue = "changeit";
	private static String trustStoreFormatValue = "jks";

	public AbstractRestTemplateClient(String contextRoot, String repositoryName, String username, String password,
			boolean useFormatExtension) throws TririgaDCTMIntegrationException
	{
		this.contextRoot = contextRoot;
		this.repositoryName = repositoryName;
		this.username = username;
		this.password = password;
		this.useFormatExtension = useFormatExtension;
		initRestTemplate(restTemplate);
	}

	static
	{
		//				System.setProperty("com.sun.net.ssl.checkRevocation", "false");
		//				logger.info("trustStorePath " + trustStorePath);
		//		System.setProperty(trustStore, trustStorePath);
		//		System.setProperty(trustStorePassword, trustStorePasswordValue);
		//		System.setProperty(trustStoreFormat, trustStoreFormatValue);
	}
	/**
	 * HomeDocument resource uri is the only fixed uri it must be:
	 * "Rest context path"/services e.g.
	 * http://localhost:8080/dctm-rest/services
	 * 
	 * @return the HomeDocument resource uri
	 */
	protected String getHomeDocumentUri()
	{
		String servicesUri = contextRoot + "/services";
		if (useFormatExtension)
		{
			switch(getClientType())
			{
			case XML:
				servicesUri += ".xml";
				break;
			case JSON:
				servicesUri += ".json";
				break;
			}
		}
		return servicesUri;
	}

	@Override
	public HttpHeaders getHeaders()
	{
		return headers;
	}

	@Override
	public HttpStatus getStatus()
	{
		return status;
	}

	public AbstractRestTemplateClient debug(boolean debug)
	{
		this.debug = debug;
		return this;
	}

	protected void initRestTemplate(RestTemplate restTemplate) throws TririgaDCTMIntegrationException
	{
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
	}

	protected abstract ClientType getClientType();

	private void setupHttp(ResponseEntity<?> entity)
	{
		if (entity == null)
		{
			headers = null;
			status = null;
		}
		else
		{
			headers = entity.getHeaders();
			status = entity.getStatusCode();
			if (debug)
			{
				Debug.debug("Response status: " + getStatus());
				Debug.debug("Response headers: " + getHeaders());
			}
		}
	}



	/**
	 * send the request and process the response by Spring RestTemplate
	 * 
	 * @param uri
	 *            the resource uri
	 * @param httpMethod
	 *            the HTTP method, e.g. GET, POST, DELETE...
	 * @param headers
	 *            the request http headers
	 * @param requestBody
	 *            the request http body
	 * @param responseBodyClass
	 *            the class to represent response
	 * @param params
	 *            request parameters
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */

	protected <T> T sendRequest(String uri, HttpMethod httpMethod, HttpHeaders headers, Object requestBody,
			Class<T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		//logger.info("SSLCall");
		//System.setProperty("com.sun.net.ssl.checkRevocation", "false");
		try 
		{
			prop.load(TririgaDCTMHelper.class.getResourceAsStream("errorCodes.properties"));
			if(prop == null)
			{
				throw new TririgaDCTMIntegrationException("Property file load is failed");
			}
		} 
		catch (IOException e1) {			
			e1.printStackTrace();
		}
		if (debug)
		{
			Debug.debug("Resource URI: " + uri);
			Debug.debug("HTTP method: " + httpMethod);
			Debug.debug("Request headers: " + headers);
			Debug.debugObject(requestBody);
			if (responseBodyClass != null)
			{
				Debug.debug("Expected response body class: " + responseBodyClass.getSimpleName());
			}
			if (params != null)
			{
				Debug.debug("Request parameters: " + UriHelper.queryString(params));
			}
		}

		if (uri == null || uri.length() == 0)
		{
			throw new IllegalStateException("The resource URI is empty, or you do not have priviledge");
		}
		uri = UriHelper.decode(uri);
		if (username != null && password != null)
		{
			HttpHeaders clonedHeader = new HttpHeaders();
			clonedHeader.putAll(headers);
			String usernameAndPassword = username + ":" + password;
			clonedHeader.add("Authorization", "Basic "
					+ new String(Base64.encodeBase64(usernameAndPassword.getBytes())));
			headers = clonedHeader;
		}
		HttpEntity<Object> requestEntity = requestBody == null ? new HttpEntity<Object>(headers)
				: new HttpEntity<Object>(requestBody, headers);
		String requestUri = UriHelper.appendQueryString(uri, params);
		if (debug)
		{
			Debug.debug("Sending " + httpMethod + " request to " + uri);
		}
		ResponseEntity<T> entity = null;
		if (enableStreaming)
		{
			ClientHttpRequestFactory factory = restTemplate.getRequestFactory();
			if (factory instanceof SimpleClientHttpRequestFactory)
			{
				((SimpleClientHttpRequestFactory) factory).setBufferRequestBody(false);
				if (debug)
				{
					Debug.debug("Enable streaming mode for request body transfer");
				}
			}
			else if (factory instanceof HttpComponentsClientHttpRequestFactory)
			{
				((HttpComponentsClientHttpRequestFactory) factory).setBufferRequestBody(false);
				if (debug)
				{
					Debug.debug("Enable streaming mode for request body transfer");
				}
			}
		}
		try
		{			
			entity = restTemplate.exchange(requestUri, httpMethod, requestEntity, responseBodyClass);
			setupHttp(entity);

		}
		catch(RestClientException e)
		{			
			if (e != null){				
				String errorStatus = e.getMessage();
				if(errorStatus.startsWith("I/O error on")){
					errorStatus = "109";
				}
				if(errorStatus.contains("(DM_FOLDER_E_PATH_EXISTS) [DM_FOLDER_E_PATH_EXISTS]") || 
						errorStatus.contains("(DM_FOLDER_E_CANT_CHANGED) [DM_FOLDER_E_CANT_CHANGED]")){
					errorStatus = "100";
				}

				switch(errorStatus){
				case "401":
					logger.info("Authentication Failed Invalid Credential Provided");
					throw new TririgaDCTMIntegrationException(prop.getProperty("Authentication"));
				case "403":
					logger.info("Insufficient Permission to perform this operation on the object");
					throw new TririgaDCTMIntegrationException(prop.getProperty("InsufficientPermission"));
				case "404":
					logger.info("Resource Specified by ID, Name, Type, or Path Cannot be Found");
					throw new TririgaDCTMIntegrationException(prop.getProperty("ResourceNotFound"));
				case "500":
					logger.info("Internal Server Error");
					throw new TririgaDCTMIntegrationException(prop.getProperty("InternalServerError"));					
				case "109":
					logger.info(e.getMessage());
					throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidURL"));
				case "100":
					return entity == null ? null : entity.getBody();
				case "E_CREATE_OBJECT_WITH_WRONG_TYPE":
					logger.info("Only dm_folder is allowed to be created in this collection");
					throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidCustFolderType"));				
				}										

			}
		}
		catch(IllegalArgumentException e)
		{			
			logger.info("URI is not absolute");
			throw new TririgaDCTMIntegrationException(prop.getProperty("InvalidURL"));
		}

		finally
		{			
			if (enableStreaming)
			{
				enableStreaming = false;
				ClientHttpRequestFactory factory = restTemplate.getRequestFactory();
				if (factory instanceof SimpleClientHttpRequestFactory)
				{
					((SimpleClientHttpRequestFactory) factory).setBufferRequestBody(true);
					if (debug)
					{
						Debug.debug("Disable streaming mode for request body transfer");
					}
				}
				else if (factory instanceof HttpComponentsClientHttpRequestFactory)
				{
					((HttpComponentsClientHttpRequestFactory) factory).setBufferRequestBody(true);
					if (debug)
					{
						Debug.debug("Disable streaming mode for request body transfer");
					}
				}
			}
		}
		return entity == null ? null : entity.getBody();
	}

	/**
	 * construct a new RestObject based on oldObject's class with new properties
	 * 
	 * @param oldObject
	 * @param newObject
	 * @return
	 */
	protected RestObject newRestObject(RestObject oldObject, RestObject newObject)
	{
		try
		{
			return oldObject.getClass().getConstructor(RestObject.class).newInstance(newObject);
		}
		catch(Exception e)
		{
			throw new IllegalArgumentException(oldObject.getClass().getName());
		}
	}

	@Override
	public RestObject createObject(RestObject parent, RestObject objectToCreate, Object content, String... params) throws TririgaDCTMIntegrationException
	{
		return createObject(parent, LinkRelation.OBJECTS, objectToCreate, content, params);
	}

	protected <T> T get(String uri, HttpHeaders headers, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		return sendRequest(uri, HttpMethod.GET, headers, null, responseBodyClass, params);
	}

	protected <T> T get(String uri, boolean isCollection, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, isXml() ? (isCollection ? Headers.ACCEPT_ATOM_HEADERS : Headers.ACCEPT_XML_HEADERS)
				: Headers.ACCEPT_JSON_HEADERS, responseBodyClass, params);
	}

	public <T> T get(String uri, Class<T> clazz, String... params) throws TririgaDCTMIntegrationException
	{
		return get(uri, false, clazz, params);
	}

	public void delete(String uri, String... params) throws TririgaDCTMIntegrationException
	{
		sendRequest(uri, HttpMethod.DELETE, isXml() ? Headers.ACCEPT_XML_HEADERS : Headers.ACCEPT_JSON_HEADERS, null,
				null, params);
	}

	@Override
	public void delete(Linkable linkable, String... params) throws TririgaDCTMIntegrationException,Exception
	{
		if (linkable.getHref(DELETE) != null)
		{
			delete(linkable.getHref(DELETE), params);
		}
		else if (linkable.getHref(SELF) != null)
		{
			delete(linkable.getHref(SELF), params);
		}
		else if (linkable.getHref(EDIT) != null)
		{
			delete(linkable.getHref(EDIT), params);
		}
		else
		{
			throw new IllegalArgumentException(String.valueOf(linkable));
		}
	}

	protected <T> T post(String uri, Object body, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		return sendRequest(uri, HttpMethod.POST, isXml() ? Headers.ACCEPT_XML_HEADERS_WITH_CONTENT
				: Headers.ACCEPT_JSON_HEADERS_WITH_CONTENT, body, responseBodyClass, params);
	}

	protected <T> T post(String uri, Object content, String mediaType, Class<? extends T> responseBodyClass,
			String... params) throws TririgaDCTMIntegrationException
	{
		return sendRequest(
				uri,
				HttpMethod.POST,
				new Headers()
				.accept(isXml() ? SupportedMediaTypes.APPLICATION_VND_DCTM_XML_VALUE
						: SupportedMediaTypes.APPLICATION_VND_DCTM_JSON_VALUE).contentType(mediaType)
						.toHttpHeaders(), content, responseBodyClass, params);
	}

	protected <T> T put(String uri, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		return sendRequest(uri, HttpMethod.PUT, isXml() ? Headers.ACCEPT_XML_HEADERS : Headers.ACCEPT_JSON_HEADERS,
				null, responseBodyClass, params);
	}

	@Override
	public RestObject update(RestObject oldObject, LinkRelation rel, RestObject newObject, HttpMethod method,
			String... params) throws TririgaDCTMIntegrationException
	{

		RestObject newRestObject = newRestObject(oldObject, newObject);
		if (method == HttpMethod.PUT)
		{
			return put(oldObject.getHref(rel), newRestObject, newRestObject.getClass(), params);
		}
		else
		{
			return post(oldObject.getHref(rel), newRestObject, newRestObject.getClass(), params);
		}

	}

	protected <T> T put(String uri, Object body, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		return sendRequest(uri, HttpMethod.PUT, isXml() ? Headers.ACCEPT_XML_HEADERS_WITH_CONTENT
				: Headers.ACCEPT_JSON_HEADERS_WITH_CONTENT, body, responseBodyClass, params);
	}

	protected <T> T post(String uri, T object, Object content, Class<? extends T> responseBodyClass, String... params) throws TririgaDCTMIntegrationException
	{
		T t = null;
		if (content == null)
		{
			t = post(uri, object, responseBodyClass, params);
		}
		else if (object != null && content != null)
		{
			Map<String, String> partHeaders = new HashMap<String, String>();
			partHeaders.put("Content-Type", isXml() ? SupportedMediaTypes.APPLICATION_VND_DCTM_XML_VALUE
					: SupportedMediaTypes.APPLICATION_VND_DCTM_JSON_VALUE);
			MultiValueMap<String, Object> parts = new LinkedMultiValueMap<String, Object>();
			parts.add("metadata", new HttpEntity<Object>(object, isXml() ? Headers.XML_CONTENT : Headers.JSON_CONTENT));
			parts.add("binary", content);
			t = sendRequest(uri, HttpMethod.POST, isXml() ? Headers.ACCEPT_XML_HEADERS_WITH_MULTIPART_CONTENT
					: Headers.ACCEPT_JSON_HEADERS_WITH_MULTIPART_CONTENT, parts, responseBodyClass, params);
		}
		return t;
	}

	/**
	 * Method to Copy the Folders from Source to Destination along with ACL as
	 * part of REST 7.3 changes
	 * 
	 * @param destUri
	 * @param srcUri
	 * @return
	 * @throws TririgaDCTMIntegrationException 
	 */
	protected <T> T postCopy(String destUri, String srcUri, Class<? extends T> responseBodyClass) throws TririgaDCTMIntegrationException
	{
		T t = null;

		logger.debug("destUri " + destUri);
		logger.debug("srcUri " + srcUri);

		Map<String, Object> parts = new HashMap<String, Object>();
		parts.put("href", srcUri);
		parts.put("replicate-vd-children", true);
		parts.put("retain-acl", true);

		t = sendRequest(destUri, HttpMethod.POST, isXml() ? Headers.ACCEPT_XML_HEADERS_WITH_CONTENT
				: Headers.ACCEPT_JSON_HEADERS_WITH_CONTENT, parts, responseBodyClass);
		return t;
	}

	@Override
	public void enableStreamingForNextRequest()
	{
		this.enableStreaming = true;
	}

	protected boolean isXml()
	{
		return ClientType.XML == getClientType();
	}

	protected boolean isJson()
	{
		return ClientType.JSON == getClientType();
	}

	protected static enum ClientType
	{
		XML, JSON
	}

}
