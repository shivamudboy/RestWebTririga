/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model.json;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tririga.documentum.rest.client.model.ObjectAspects;
import com.tririga.documentum.rest.client.util.Equals;

public class JsonObjectAspects extends JsonLinkableBase implements ObjectAspects {
    @JsonProperty
    private List<String> aspects;
    
    public JsonObjectAspects() {
    }
    
    public JsonObjectAspects(String... aspects) {
        this.aspects = Arrays.asList(aspects);
    }

    @Override
    public List<String> getAspects() {
        return aspects;
    }

    public void setAspects(List<String> aspects) {
        this.aspects = aspects;
    }

    @Override
    public boolean equals(Object obj) {
        JsonObjectAspects that = (JsonObjectAspects)obj;
        return Equals.equal(aspects, that.aspects);
    }

    @Override
    public int hashCode() {
        return Objects.hash(aspects);
    }
}
