package com.tririga.documentum.rest.client.model.json;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tririga.documentum.rest.client.model.Link;
import com.tririga.documentum.rest.client.model.LinkableBase;

public abstract class JsonLinkableBase extends LinkableBase {
    @JsonProperty
    protected List<JsonLink> links;
    
    @Override
    public List<Link> getLinks() {
        return links==null?null:new ArrayList<Link>(links);
    }

    public void setLinks(List<JsonLink> links) {
        this.links = links;
    }
}
