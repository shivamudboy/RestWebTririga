/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model;

import java.util.List;

/**
 * the class represents the search entry of a feed
 */
public interface SearchEntry<T extends Linkable> extends Entry<T> {
    public String getScore();
    public List<String> getTerms();
}
