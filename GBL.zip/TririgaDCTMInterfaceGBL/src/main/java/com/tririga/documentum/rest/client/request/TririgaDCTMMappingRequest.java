/**
 * 
 */

package com.tririga.documentum.rest.client.request;

public class TririgaDCTMMappingRequest
{

	// Documentum Params
	private String userId;
	private String password;
	private String url;
	private String repos;
	private String extension;
	// Action Params
	private String requestType;
	private String action;
	private String formName;
	// Create Folder Params
	private String cabinetName;
	private String folderNameInCabinet;
	private String folderNametoCreate;
	// LookUp Params
	private String newFolderName;
	private String objectId;
	private String folderNametoUpdate;
	// Copy Folder Params
	private String templateFolderName;
	// Move Folder Params
	private String folderNametoMove;
	private String folderNameAtArchive;
	// Generic Params for all Requests
	private boolean copyCreateFolder;
	private String marketCode;
	private String templateCabinetName;
	private String customFolderType;
	private String storeNo;
	
	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getCustomFolderType() {
		return customFolderType;
	}

	public void setCustomFolderType(String customFolderType) {
		this.customFolderType = customFolderType;
	}

	/**
	 * @return the templateCabinetName
	 */
	public String getTemplateCabinetName()
	{
		return templateCabinetName;
	}

	/**
	 * @param templateCabinetName
	 *            the templateCabinetName to set
	 */
	public void setTemplateCabinetName(String templateCabinetName)
	{
		this.templateCabinetName = templateCabinetName;
	}

	/**
	 * @return the copyCreateFolder
	 */
	public boolean isCopyCreateFolder()
	{
		return copyCreateFolder;
	}

	/**
	 * @param copyCreateFolder
	 *            the copyCreateFolder to set
	 */
	public void setCopyCreateFolder(boolean copyCreateFolder)
	{
		this.copyCreateFolder = copyCreateFolder;
	}

	/**
	 * @return the marketCode
	 */
	public String getMarketCode()
	{
		return marketCode;
	}

	/**
	 * @param marketCode
	 *            the marketCode to set
	 */
	public void setMarketCode(String marketCode)
	{
		this.marketCode = marketCode;
	}

	/**
	 * @return the folderNameAtArchive
	 */
	public String getFolderNameAtArchive()
	{
		return folderNameAtArchive;
	}

	/**
	 * @param folderNameAtArchive
	 *            the folderNameAtArchive to set
	 */
	public void setFolderNameAtArchive(String folderNameAtArchive)
	{
		this.folderNameAtArchive = folderNameAtArchive;
	}

	/**
	 * @return the templateFolderName
	 */
	public String getTemplateFolderName()
	{
		return templateFolderName;
	}

	/**
	 * @param templateFolderName
	 *            the templateFolderName to set
	 */
	public void setTemplateFolderName(String templateFolderName)
	{
		this.templateFolderName = templateFolderName;
	}

	/**
	 * @return the formName
	 */
	public String getFormName()
	{
		return formName;
	}

	/**
	 * @param formName
	 *            the formName to set
	 */
	public void setFormName(String formName)
	{
		this.formName = formName;
	}

	/**
	 * @return the objectId
	 */
	public String getObjectId()
	{
		return objectId;
	}

	/**
	 * @param objectId
	 *            the objectId to set
	 */
	public void setObjectId(String objectId)
	{
		this.objectId = objectId;
	}

	/**
	 * @return the newFolderName
	 */
	public String getNewFolderName()
	{
		return newFolderName;
	}

	/**
	 * @param newFolderName
	 *            the newFolderName to set
	 */
	public void setNewFolderName(String newFolderName)
	{
		this.newFolderName = newFolderName;
	}

	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}

	/**
	 * @return the url
	 */
	public String getUrl()
	{
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url)
	{
		this.url = url;
	}

	/**
	 * @return the repos
	 */
	public String getRepos()
	{
		return repos;
	}

	/**
	 * @param repos
	 *            the repos to set
	 */
	public void setRepos(String repos)
	{
		this.repos = repos;
	}

	/**
	 * @return the extension
	 */
	public String getExtension()
	{
		return extension;
	}

	/**
	 * @param extension
	 *            the extension to set
	 */
	public void setExtension(String extension)
	{
		this.extension = extension;
	}

	/**
	 * @return the cabinetName
	 */
	public String getCabinetName()
	{
		return cabinetName;
	}

	/**
	 * @param cabinetName
	 *            the cabinetName to set
	 */
	public void setCabinetName(String cabinetName)
	{
		this.cabinetName = cabinetName;
	}

	/**
	 * @return the requestType
	 */
	public String getRequestType()
	{
		return requestType;
	}

	/**
	 * @param requestType
	 *            the requestType to set
	 */
	public void setRequestType(String requestType)
	{
		this.requestType = requestType;
	}

	/**
	 * @return the action
	 */
	public String getAction()
	{
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action)
	{
		this.action = action;
	}

	/**
	 * @return the folderNameInCabinet
	 */
	public String getFolderNameInCabinet()
	{
		return folderNameInCabinet;
	}

	/**
	 * @param folderNameInCabinet
	 *            the folderNameInCabinet to set
	 */
	public void setFolderNameInCabinet(String folderNameInCabinet)
	{
		this.folderNameInCabinet = folderNameInCabinet;
	}

	/**
	 * @return the folderNametoCreate
	 */
	public String getFolderNametoCreate()
	{
		return folderNametoCreate;
	}

	/**
	 * @param folderNametoCreate
	 *            the folderNametoCreate to set
	 */
	public void setFolderNametoCreate(String folderNametoCreate)
	{
		this.folderNametoCreate = folderNametoCreate;
	}

	/**
	 * @return the folderNametoUpdate
	 */
	public String getFolderNametoUpdate()
	{
		return folderNametoUpdate;
	}

	/**
	 * @param folderNametoUpdate
	 *            the folderNametoUpdate to set
	 */
	public void setFolderNametoUpdate(String folderNametoUpdate)
	{
		this.folderNametoUpdate = folderNametoUpdate;
	}

	/**
	 * @return the folderNametoMove
	 */
	public String getFolderNametoMove()
	{
		return folderNametoMove;
	}

	/**
	 * @param folderNametoMove
	 *            the folderNametoMove to set
	 */
	public void setFolderNametoMove(String folderNametoMove)
	{
		this.folderNametoMove = folderNametoMove;
	}

}
