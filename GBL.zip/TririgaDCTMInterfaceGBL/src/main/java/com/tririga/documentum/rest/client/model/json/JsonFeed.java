/*
 * Copyright (c) 2016. EMC Corporation. All Rights Reserved.
 */
package com.tririga.documentum.rest.client.model.json;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tririga.documentum.rest.client.model.Entry;
import com.tririga.documentum.rest.client.model.Feed;
import com.tririga.documentum.rest.client.model.InlineLinkable;

public class JsonFeed<T extends InlineLinkable> extends JsonFeedBase<T, Entry<T>> implements Feed<T> {
    @JsonProperty
    private List<JsonEntry<T>> entries;

    @Override
    public List<Entry<T>> getEntries() {
        return entries==null?null:new ArrayList<Entry<T>>(entries);
    }

    public void setEntries(List<JsonEntry<T>> entries) {
        this.entries = entries;
    }
}
