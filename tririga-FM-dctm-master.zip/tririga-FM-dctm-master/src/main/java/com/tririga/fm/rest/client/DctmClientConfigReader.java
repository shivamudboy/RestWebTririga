package com.tririga.fm.rest.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.tririga.platform.smartobject.domain.SmartObject;
import com.tririga.platform.smartobject.domain.field.SmartObjectFieldValueAccessor;
import com.tririga.platform.smartobject.service.SmartObjectUtils;
import com.tririga.pub.workflow.WFStepInfo;
import com.tririga.pub.workflow.WFVariable;

public class DctmClientConfigReader {

	private static Logger logger = Logger.getLogger(DctmClientConfigReader.class.toString());
	
	
	private  DctmBean bean;

	
	
	
	
	
	/**
	 * 
	 * @return
	 */
	public DctmClientConfigReader(Map parameters)
	{
			setDctmParams(parameters);
	}
	
	
	
	public  void setDctmParams(Map parameters)
	{
		logger.info(" BEGIN SET DOCUMENTUM CREDENTIALS ");
		
        Collection<SmartObject> params = getParameterSmartObjects(parameters, DctmContant.DCTM_TRIRIGA_VAR1);
        Collection<SmartObject> params1 = getParameterSmartObjects(parameters, DctmContant.DCTM_TRIRIGA_VAR3);
         
        if (params.size() > 0 || params1.size() > 0) { 
        	bean = new DctmBean();
        	for(SmartObject so : params) { 
            	
            	bean.setDocbase(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_DOCBASE)));
            	bean.setUser(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_USER)));
            	bean.setPass(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_PASS)));
            	bean.setUrl(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_RESTURL)));
            	bean.setExtension(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_EXTN)));
            	bean.setWebUrl(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_WEBTOP)));
            	bean.setMarketType(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_MARKETTYPE)));
            }
        	for(SmartObject so : params1) { 
            	
            	bean.setDocbase(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_DOCBASE)));
            	bean.setUser(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_USER)));
            	bean.setPass(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_PASS)));
            	bean.setUrl(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_RESTURL)));
            	bean.setExtension(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_EXTN)));
            	bean.setWebUrl(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_WEBTOP)));
            	bean.setMarketType(SmartObjectFieldValueAccessor.getString(so.getField(DctmContant.DCTM_MARKETTYPE)));
            }
            
     }
        
       this.setDctmBean(bean);
        
       logger.info(" END SET DOCUMENTUM CREDENTIALS ");
	}
	
	
	
	/**
	 * Get Result ID
	 * @param params
	 * @param name
	 * @return
	 */
    public  Collection<SmartObject> getParameterSmartObjects(Map params, String name) {
    	
    	logger.info(" BEGIN getParameterSmartObjects ");
    	
        ArrayList<SmartObject> result = new ArrayList<SmartObject>(); 
        WFVariable targetTasksVar = (WFVariable)params.get(name);
        
        if (targetTasksVar != null) { 
                WFStepInfo targetTaskStepInfo = (WFStepInfo)targetTasksVar.getValue(); 
                
                
                Collection resultIds = targetTaskStepInfo.getResultRecordIds(); 
                logger.info("result size: "+resultIds.size()); 
                
                	for(Iterator<Long> iter = resultIds.iterator();iter.hasNext();) { 
                        try {result.add(SmartObjectUtils.getSmartObject(iter.next().longValue()));} catch (com.tririga.platform.smartobject.dataaccess.SmartObjectNotFoundException sonfe) {} 
                	}
                
        } else { 
        	logger.error("No such parameter '"+name+"' found"); 
        } 
        
        logger.info(" END getParameterSmartObjects ");
        return(result); 
}
    
    
    
    /**
     * 
     * @return
     */
    public DctmBean getDctmBean()
    {
    	return this.bean;
    }
    
    
    public void setDctmBean(DctmBean bean)
    {
    	this.bean=bean;
    }
	
}
