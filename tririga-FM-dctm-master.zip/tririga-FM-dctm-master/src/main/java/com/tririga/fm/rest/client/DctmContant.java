package com.tririga.fm.rest.client;

public interface DctmContant {

	
	public final static String DCTM_USER = "cstDCTMUserTX";
	public final static String DCTM_PASS = "cstDCTMPasswordTX";
	public final static String DCTM_DOCBASE = "cstDCTMDocBaseTX";
	public final static String DCTM_RESTURL = "cstDCTMRESTURLTX";
	public final static String DCTM_EXTN = "cstDCTMFormatExtensionTX";
	public final static String DCTM_WEBTOP = "cstWebTopURL";
	public final static String DCTM_MARKETTYPE = "cstMarketTypeTX";
	public final static String DCTM_TRIRIGA_VAR1 = "dctm_tririga";
	public final static String DCTM_TRIRIGA_VAR2 = "dctm_cabinet_acl";
	public final static String DCTM_TRIRIGA_VAR3 = "dctm_tririga1";
	public final static String DCTM_TRIRIGA_VAR4 = "dctm_cabinet_acl1";
	public final static String DCTM_BINDING =  "JSON";
	
	public final static String DCTM_CABINETNAME =  "cstCabinetName";
}
