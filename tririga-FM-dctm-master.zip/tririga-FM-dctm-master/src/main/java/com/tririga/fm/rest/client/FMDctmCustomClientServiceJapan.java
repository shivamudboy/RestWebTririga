package com.tririga.fm.rest.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.tririga.documentum.rest.client.TririgaDCTMInterface;
import com.tririga.documentum.rest.client.request.TririgaDCTMMappingRequest;
import com.tririga.documentum.rest.client.response.TririgaDCTMMappingResponse;
import com.tririga.platform.context.ContextService;
import com.tririga.platform.smartobject.domain.SmartObject;
import com.tririga.platform.smartobject.domain.field.SmartObjectFieldValueAccessor;
import com.tririga.platform.smartobject.service.SmartObjectUtils;
import com.tririga.platform.util.locator.Locator;
import com.tririga.pub.workflow.CustomParamTask;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.CustomParamTaskResultImpl;
import com.tririga.pub.workflow.Record;
import com.tririga.pub.workflow.WFStepInfoImpl;
import com.tririga.pub.workflow.WFVariable;

public class FMDctmCustomClientServiceJapan implements CustomParamTask {

	private static Logger logger = Logger
			.getLogger(FMDctmCustomClientServiceJapan.class.toString());

	/**
	 * Call to create the documentum folder structure based on the object type
	 */
	public CustomParamTaskResult execute(Map parameters, long userId,
			Record[] records) {

		SmartObject smartObject = null;
		long ID = 0;

		String triID = "";
		String recordID = "";
		String recordName = "";
		String dctmUrl = "";
		String dctmFolder = "";
		String tririgaBoName = "";
		DctmBean dctmBean = null;
		String country = null;
		String ctryCode = "";
		String errorMessage = "";
		String boFormNameSY = "";
		String tririgaTemplateFolderName = "";
		String folderNameofForm = "";
		String storeNo = "";
		boolean isCopy = false;
		boolean isCallDocumentum = true;

		logger.info(" ***************************************** ");
		logger.info(" BEGIN EXECUTION ");
		logger.info(" ***************************************** ");
		for (int i = 0; i < records.length; i++) {
			Record record = records[i];
			ID = record.getRecordId();
			smartObject = SmartObjectUtils.getSmartObject(record.getRecordId());
			// recordID
			// Tririga System Id
			triID=SmartObjectFieldValueAccessor.getString(smartObject.getField("triIdTX"));
			
			recordID = SmartObjectFieldValueAccessor.getString(smartObject.getField("triRecordIdSY"));
			logger.info("Record id TX: " + recordID);
			recordName = SmartObjectFieldValueAccessor.getString(smartObject.getField("triNameTX"));
			dctmUrl = SmartObjectFieldValueAccessor.getString(smartObject.getField("cstDocumentumURL"));
			country = SmartObjectFieldValueAccessor.getString(smartObject.getField("cstSystemCountryTX"));
			tririgaBoName = smartObject.getMetadata().getName();
			boFormNameSY = SmartObjectFieldValueAccessor.getString(smartObject.getField("triFormNameSY"));
			
			logger.info("---------------form and BO--------" + boFormNameSY+ "-----------" + tririgaBoName);
			logger.info(record.toString() + " ID :" + recordID + " Name :"+ recordName + " dctmUrl:" + dctmUrl + " Object Type:"+ tririgaBoName + " country:" + country);
		}

		Collection resultRecordIds = new ArrayList();

		for (int i = 0; i < records.length; i++) {
			if (i % 2 == 0) {
				Record record = records[i];
				resultRecordIds.add(record.getId());
			}
		}

		switch (country) {
		case "United States":ctryCode = "US";break;
		case "Puerto Rico":ctryCode = "US";break;
		case "Costa Rica":ctryCode = "CAM";break;
		case "El Salvador":ctryCode = "CAM";break;
		case "Guatemala":ctryCode = "CAM";break;
		case "Nicaragua":ctryCode = "CAM";break;
		case "Honduras":ctryCode = "CAM";break;
		case "Mexico":ctryCode = "MX";break;
		case "China":ctryCode = "CN";break;
		case "Japan":ctryCode = "JP";break;
		}

		if (null == dctmUrl) {
			logger.info("*****BO NAME : " + tririgaBoName);
			try {
				logger.info("DCTM URL is null");
				DctmClientConfigReader dctmReader = new DctmClientConfigReader(parameters);
				HashMap<String, String> propvals = DctmPropReader.readProperty();
				logger.info("Reading property file for the inputted params");
				String dctmVal = "";

				if ((boFormNameSY != null) && !(boFormNameSY.equals(""))) {
					dctmVal = (String) propvals.get(boFormNameSY);
				} else {
					dctmVal = (String) propvals.get(tririgaBoName);
				}

				dctmFolder = dctmVal.substring(0, dctmVal.indexOf("|"));
				String Cabinet = dctmVal.substring((dctmVal.indexOf("|") + 1),dctmVal.length());

				logger.info("-----------folder name : " + dctmFolder+ "-----property file entry : " + dctmVal+ "---cabinet name : " + Cabinet + "----");

				
				dctmBean = dctmReader.getDctmBean();
				

				logger.info("dctmBean: " + dctmBean.toString());
				logger.info("getDocbase: " + dctmBean.getDocbase());
				logger.info("getExtension: " + dctmBean.getExtension());
				logger.info("getUrl: " + dctmBean.getUrl());
				logger.info("getUser: " + dctmBean.getUser());
				logger.info("dctmFolder: " + dctmFolder);
				logger.info("Cabinet: " + ctryCode + " " + Cabinet.trim());
				logger.info("Market Type: " + dctmBean.getMarketType());

				TririgaDCTMInterface dctmObj = new TririgaDCTMInterface();
				TririgaDCTMMappingRequest dctmReq = new TririgaDCTMMappingRequest();
				dctmReq.setCabinetName(ctryCode + " " + Cabinet.trim());
				dctmReq.setUserId(dctmBean.getUser());
				dctmReq.setPassword(dctmBean.getPass());
				dctmReq.setFolderNameInCabinet(dctmFolder);
				dctmReq.setUrl(dctmBean.getUrl());
				dctmReq.setExtension(dctmBean.getExtension());
				dctmReq.setRepos(dctmBean.getDocbase());
				dctmReq.setAction("1");

				logger.info(" INSIDE CREATE FOLDER");
				logger.info("==========================++++++++++++++++++++++"+ boFormNameSY);

				// Complex Folders
					
				// Required for complex folder structure to fetch the form name in webtop under tririgatemplates
				dctmReq.setFormName(boFormNameSY);

				// it is set to true : true means, it will create a defined folder structure in webtop under the record folder
				dctmReq.setCopyCreateFolder(true);
				
				// for triBuildingEquipment it is simple folder structure
				if(boFormNameSY.equalsIgnoreCase("triBuildingEquipment"))
				{
					dctmReq.setCopyCreateFolder(false);
					
				}

				dctmReq.setTemplateCabinetName("TririgaTemplates");

				// template folder name should have country code in prefix.
				// example : "US Portfolio" or "MX Portfolio" or
				// "CAM Portfolio"...
				
				// checking here for portfolio forms, as portfolio forms should be concatenated with just "JP"
				if ((ctryCode != null) && !(ctryCode.equalsIgnoreCase(""))) 
				{
					tririgaTemplateFolderName = tririgaTemplateFolderName
							.concat(ctryCode);
					//Portfolio Forms
					if ((boFormNameSY.equalsIgnoreCase("triBuildingEquipment"))
							|| (boFormNameSY
									.equalsIgnoreCase("triBuildingEquipmentSpec"))) {
						tririgaTemplateFolderName = tririgaTemplateFolderName
								.concat(" Portfolio");
					} else // FM Forms
					{
						tririgaTemplateFolderName = tririgaTemplateFolderName
								.concat(" FM");
					}
				}
				logger.info("----------------tririga template folder name-------------------"+ tririgaTemplateFolderName);
				dctmReq.setTemplateFolderName(tririgaTemplateFolderName);

					// Folder name for all forms of FM is RecordId,store#,Name of the record
					if(boFormNameSY.equalsIgnoreCase("triBuildingEquipment"))
					{
						storeNo = SmartObjectFieldValueAccessor.getString(smartObject.getField("cstStore#"));
					}
					else
					{
						storeNo = SmartObjectFieldValueAccessor.getString(smartObject.getField("cstStore#TX"));
					}
					
					
					if (storeNo != null)
					{
						logger.info("Store number is not empty, hence folder name will consist of Store #, triIdTX, triNameTX, CountryCode, System ID ");
						folderNameofForm = folderNameofForm.concat(storeNo);
						folderNameofForm = folderNameofForm.concat(",");
					}
					else
					{
						logger.info("Store number is empty, hence folder name will consist of , triIdTX, triNameTX, CountryCode, System ID ");
						folderNameofForm = folderNameofForm.concat(",");
					}
					    folderNameofForm = folderNameofForm.concat(triID);
					    folderNameofForm = folderNameofForm.concat(",");
					    folderNameofForm = folderNameofForm.concat(recordName);
					    folderNameofForm = folderNameofForm.concat(",");
					    folderNameofForm = folderNameofForm.concat(ctryCode);
						folderNameofForm = folderNameofForm.concat(",");
						folderNameofForm = folderNameofForm.concat(recordID);
						folderNameofForm = folderNameofForm.concat(",");
						
						
						logger.info("---folder name for  form : "+ folderNameofForm);
						dctmReq.setFolderNametoCreate(folderNameofForm);
						
					errorMessage = "Unable to Create folder. Please contact the Administrator";// error message should be same across all forms

				if (isCallDocumentum) {
					logger.info("Calling Documentum...");
					TririgaDCTMMappingResponse respDCTM = dctmObj.invokeDCTM(dctmReq);
					logger.info("Generated Object ID: "+ respDCTM.getObjectId());
					if (!isCopy)
					SmartObjectFieldValueAccessor.setString(smartObject.getField("cstDocumentumURL"),getUrl(dctmBean.getWebUrl(),respDCTM.getObjectId()));
				}
				errorMessage = "Unable to Create folder. Please contact the Administrator";// error message should be same across all forms	
																							
				synchronized (SmartObjectUtils.findCurrentContext()) {((ContextService) Locator.getInstance().locate("contextService")).commit(SmartObjectUtils
							.findCurrentContext());
				}

			}
			catch (Exception exp) {
				logger.info("Exception thrown:" + exp.getMessage());
				exp.printStackTrace();
				WFStepInfoImpl wfStepInfo = new WFStepInfoImpl();
				wfStepInfo.setRecordList(resultRecordIds);
				wfStepInfo.setResultCount(new Long(resultRecordIds.size()));
				wfStepInfo.setSuccess(Boolean.FALSE);
				wfStepInfo.setStatus("Custom");
				// Create a WFVariable that contains it.
				WFVariable returnParam1 = new WFVariable("dctm", wfStepInfo);

				CustomParamTaskResultImpl taskResult = new CustomParamTaskResultImpl();
				// Create the return parameters map.
				HashMap returnParams = new HashMap();
				// Add our value to the map.
				returnParams.put(returnParam1.getName(), returnParam1);
				// Set the map on the result.
				taskResult.setReturnParameters(returnParams);
				// Set our status.
				taskResult.setExecutionWasSuccessful(false);
				
				SmartObjectFieldValueAccessor.setString(smartObject.getField("cstDocumentumErrorMsgTX"),errorMessage);
				
				errorMessage = "Unable to Create folder. Please contact the Administrator";// error message should be same across all forms
				logger.info("error message is : " + errorMessage);
				synchronized (SmartObjectUtils.findCurrentContext()) {((ContextService) Locator.getInstance().locate("contextService")).commit(SmartObjectUtils.findCurrentContext());
				}
			}
		}

		WFStepInfoImpl wfStepInfo = new WFStepInfoImpl();
		wfStepInfo.setRecordList(resultRecordIds);
		wfStepInfo.setResultCount(new Long(resultRecordIds.size()));
		wfStepInfo.setSuccess(Boolean.TRUE);
		wfStepInfo.setStatus("Custom");
		// Create a WFVariable that contains it.
		WFVariable returnParam1 = new WFVariable("folder_name", wfStepInfo);
		// returnParam1.setValue("TEST");
		// Create the CustomParamTaskResult to return.
		CustomParamTaskResultImpl taskResult = new CustomParamTaskResultImpl();
		// Create the return parameters map.
		HashMap returnParams = new HashMap();
		// Add our value to the map.
		returnParams.put(returnParam1.getName(), returnParam1);
		// Set the map on the result.
		taskResult.setReturnParameters(returnParams);
		// Set our status.
		taskResult.setExecutionWasSuccessful(true);
		// Return it.
		logger.info(" ***************************************** ");
		logger.info(" END EXECUTION ");
		logger.info(" ***************************************** ");
		return taskResult;
	}

	private String getUrl(String url, String ObjectId) {
		return url + ObjectId;
	}
}