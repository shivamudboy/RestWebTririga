package com.tririga.fm.rest.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;

public class DctmPropReader {

	private static Logger logger = Logger.getLogger(DctmPropReader.class.toString());
	
public static HashMap<String, String> readProperty()
{
	Properties prop = new Properties();
	 InputStream input;
	 HashMap<String, String> propvals = new HashMap<String, String>();
	 try {
	 
	 input = DctmPropReader.class.getResourceAsStream("fmdctmFolder.properties");
	prop.load(input);
	// prop.load(new InputStreamReader(input, "UTF-8"));
	 logger.info("Property File Loaded Succesfully");
	 Set<String> propertyNames = prop.stringPropertyNames();
	 	for (String Property : propertyNames)
		 {
	 		 logger.info(Property + ":"+ prop.getProperty(Property));
			 propvals.put(Property, prop.getProperty(Property));
		 }
	 
	 } catch (IOException e) {
	 e.printStackTrace();
	 return propvals;
	 }
	return propvals;
}
	
}
